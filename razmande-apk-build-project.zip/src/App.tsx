import { useEffect, useState } from 'react';
import Game, { type Settings } from './components/Game';
import { WEAPONS, getWeapon, type Weapon } from './game/weapons';
import { audio } from './game/audio';
import type { Cheats } from './game/Engine';

type Screen = 'menu' | 'armory' | 'settings' | 'game' | 'maps';

const fa = (n: number) => n.toLocaleString('fa-IR');
const load = <T,>(k: string, d: T): T => {
  try { const v = localStorage.getItem(k); return v ? { ...d, ...JSON.parse(v) } : d; } catch { return d; }
};

const CODES: Record<string, { key: keyof Cheats; label: string; desc: string }> = {
  '1391': { key: 'infAmmo', label: 'مهمات بی‌نهایت', desc: 'تیر و نارنجک هیچ‌وقت تمام نمی‌شود' },
  '1392': { key: 'god', label: 'جان بی‌نهایت', desc: 'رزمنده آسیب نمی‌بیند' },
  '1393': { key: 'power', label: 'قدرت فوق‌العاده', desc: 'آسیب ×۵، سرعت بیشتر، همه سلاح‌ها و ۱۰ نارنجک' },
};

export default function App() {
  const [screen, setScreen] = useState<Screen>('menu');
  const [settings, setSettings] = useState<Settings>(() => load('razmande-settings', { sensitivity: 1, quality: 'medium', volume: 0.8, music: true, leftFire: true } as Settings));
  const [cheats, setCheats] = useState<Cheats>(() => load('razmande-cheats', { infAmmo: false, god: false, power: false }));
  const [loadout, setLoadout] = useState<{ primary: string; secondary: string }>(() => load('razmande-loadout', { primary: 'ak', secondary: 'colt' }));
  const [stats, setStats] = useState(() => load('razmande-stats', { kills: 0, score: 0, games: 0 }));
  const [map, setMap] = useState<'city' | 'desert'>('city');
  const [portrait, setPortrait] = useState(false);

  useEffect(() => localStorage.setItem('razmande-settings', JSON.stringify(settings)), [settings]);
  useEffect(() => localStorage.setItem('razmande-cheats', JSON.stringify(cheats)), [cheats]);
  useEffect(() => localStorage.setItem('razmande-loadout', JSON.stringify(loadout)), [loadout]);
  useEffect(() => localStorage.setItem('razmande-stats', JSON.stringify(stats)), [stats]);

  useEffect(() => {
    const check = () => setPortrait(window.innerHeight > window.innerWidth && 'ontouchstart' in window);
    check();
    window.addEventListener('resize', check);
    return () => window.removeEventListener('resize', check);
  }, []);

  const level = Math.floor(stats.score / 1500) + 1;

  const go = (s: Screen) => {
    audio.init();
    audio.setVolume(settings.volume);
    audio.click();
    if (settings.music && s !== 'game') audio.startMusic();
    setScreen(s);
  };

  const startGame = async (m: 'city' | 'desert') => {
    setMap(m);
    audio.init();
    try {
      await document.documentElement.requestFullscreen?.();
      await (window.screen.orientation as any)?.lock?.('landscape');
    } catch { /* not supported */ }
    setScreen('game');
  };

  if (screen === 'game') {
    return (
      <>
        <Game
          loadout={[loadout.primary, loadout.secondary]}
          cheats={cheats}
          settings={settings}
          map={map}
          onExit={(r) => {
            if (r) setStats((s) => ({ kills: s.kills + r.kills, score: s.score + r.score, games: s.games + 1 }));
            setScreen('menu');
            if (settings.music) audio.startMusic();
          }}
        />
        {portrait && <RotateOverlay />}
      </>
    );
  }

  return (
    <div dir="rtl" className="fixed inset-0 overflow-hidden bg-black text-white select-none font-[Vazirmatn,Tahoma,sans-serif]">
      <div className="absolute inset-0 bg-cover bg-center scale-105" style={{ backgroundImage: 'url(./menu-bg.jpg)' }} />
      <div className="absolute inset-0 bg-gradient-to-l from-black/80 via-black/20 to-black/60" />

      {screen === 'menu' && <Menu level={level} stats={stats} loadout={loadout} cheats={cheats} go={go} />}
      {screen === 'maps' && <Maps onBack={() => go('menu')} onPick={startGame} />}
      {screen === 'armory' && <Armory loadout={loadout} setLoadout={setLoadout} onBack={() => go('menu')} />}
      {screen === 'settings' && <SettingsScreen settings={settings} setSettings={setSettings} cheats={cheats} setCheats={setCheats} onBack={() => go('menu')} />}
      {portrait && <RotateOverlay />}
    </div>
  );
}

function RotateOverlay() {
  return (
    <div dir="rtl" className="fixed inset-0 z-50 bg-black flex flex-col items-center justify-center text-white text-center p-6">
      <div className="text-7xl animate-spin [animation-duration:3s] mb-4">📱</div>
      <h2 className="text-2xl font-black text-yellow-400 mb-2">گوشی را افقی کنید</h2>
      <p className="text-white/70">بازی رزمنده فقط در حالت افقی اجرا می‌شود</p>
    </div>
  );
}

function TopBar({ level, stats }: { level: number; stats: { score: number; kills: number } }) {
  return (
    <div className="absolute top-0 inset-x-0 flex items-center justify-between p-3 z-10">
      <div className="flex items-center gap-3 bg-black/50 rounded-xl px-3 py-1.5 border border-white/10">
        <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-yellow-400 to-amber-700 flex items-center justify-center text-2xl">🪖</div>
        <div>
          <div className="font-black">رزمنده</div>
          <div className="text-xs text-yellow-300">سطح {fa(level)} ★</div>
        </div>
      </div>
      <div className="flex gap-2 text-sm">
        <div className="bg-black/50 rounded-lg px-3 py-1.5 border border-white/10">🪙 {fa(stats.score)}</div>
        <div className="bg-black/50 rounded-lg px-3 py-1.5 border border-white/10">💀 {fa(stats.kills)}</div>
      </div>
    </div>
  );
}

function Menu({ level, stats, loadout, cheats, go }: { level: number; stats: { score: number; kills: number; games: number }; loadout: { primary: string; secondary: string }; cheats: Cheats; go: (s: Screen) => void }) {
  const p = getWeapon(loadout.primary);
  const anyCheat = cheats.infAmmo || cheats.god || cheats.power;
  return (
    <>
      <TopBar level={level} stats={stats} />
      <div className="absolute inset-0 flex items-center justify-between px-5 pt-14 pb-4">
        {/* right column (RTL start): title + modes */}
        <div className="flex flex-col gap-2 w-[38%] max-w-sm">
          <h1 className="text-5xl md:text-6xl font-black tracking-tight bg-gradient-to-b from-yellow-200 to-amber-600 bg-clip-text text-transparent drop-shadow-[0_3px_0_rgba(0,0,0,0.6)]">رزمنده</h1>
          <p className="text-xs text-white/70 -mt-1 mb-1">نبرد شهری • جهان باز • سه‌بعدی</p>
          <ModeBtn title="چندنفره (آفلاین)" sub="نبرد شهری با ربات‌ها" color="from-red-700/90 to-red-900/80" onClick={() => go('maps')} icon="⚔️" />
          <ModeBtn title="زرادخانه" sub={`${fa(WEAPONS.length)} سلاح مختلف`} color="from-zinc-700/90 to-zinc-900/80" onClick={() => go('armory')} icon="🔫" />
          <ModeBtn title="تنظیمات و کدها" sub="کدهای مود ۱۳۹۱ ۱۳۹۲ ۱۳۹۳" color="from-zinc-700/90 to-zinc-900/80" onClick={() => go('settings')} icon="⚙️" />
        </div>
        {/* left column: loadout + start */}
        <div className="flex flex-col items-end gap-3 w-[34%] max-w-xs">
          <div className="bg-black/55 border border-white/15 rounded-xl p-3 w-full">
            <div className="text-[11px] text-white/60 mb-1">تجهیزات فعلی</div>
            <div className="font-bold text-yellow-300">{p.name}</div>
            <div className="text-xs text-white/70">+ {getWeapon(loadout.secondary).name}</div>
          </div>
          {anyCheat && <div className="bg-fuchsia-700/80 rounded-lg px-3 py-1 text-xs font-bold w-full text-center">⚡ مود فعال است</div>}
          <button onClick={() => go('maps')} className="w-full py-4 rounded-xl bg-gradient-to-b from-yellow-400 to-amber-600 text-black text-2xl font-black shadow-[0_6px_0_#7a4a00] active:translate-y-1 active:shadow-[0_2px_0_#7a4a00] transition">
            شروع نبرد ▶
          </button>
          <div className="text-[10px] text-white/50">سازنده: محمد حسین محسن آبادی</div>
        </div>
      </div>
    </>
  );
}

function ModeBtn({ title, sub, color, onClick, icon }: { title: string; sub: string; color: string; onClick: () => void; icon: string }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-3 text-right bg-gradient-to-l ${color} border border-white/15 rounded-xl px-4 py-2.5 hover:scale-[1.02] active:scale-95 transition`}>
      <span className="text-3xl">{icon}</span>
      <span>
        <span className="block font-black text-lg leading-tight">{title}</span>
        <span className="block text-xs text-white/70">{sub}</span>
      </span>
    </button>
  );
}

function Maps({ onBack, onPick }: { onBack: () => void; onPick: (m: 'city' | 'desert') => void }) {
  const maps = [
    { id: 'city' as const, name: 'شهر جنگ‌زده', desc: 'خیابان‌ها، ساختمان‌های بلند، کانتینرها و ماشین‌ها', grad: 'from-zinc-600 to-stone-800' },
    { id: 'desert' as const, name: 'پایگاه صحرایی', desc: 'بیابان گرم، کوه‌های دوردست و ساختمان‌های گلی', grad: 'from-amber-500 to-orange-800' },
  ];
  return (
    <div className="absolute inset-0 flex flex-col p-5">
      <Header title="انتخاب نقشه" onBack={onBack} />
      <div className="flex-1 flex items-center justify-center gap-6">
        {maps.map((m) => (
          <button key={m.id} onClick={() => onPick(m.id)} className={`w-[38%] max-w-sm aspect-video rounded-2xl bg-gradient-to-br ${m.grad} border-2 border-white/20 hover:border-yellow-400 p-4 flex flex-col justify-end text-right active:scale-95 transition shadow-2xl`}>
            <div className="text-2xl font-black">{m.name}</div>
            <div className="text-xs text-white/80">{m.desc}</div>
            <div className="mt-2 self-start bg-yellow-400 text-black font-black rounded px-3 py-1 text-sm">ورود ▶</div>
          </button>
        ))}
      </div>
      <p className="text-center text-xs text-white/60">هدف: ۵۰ دشمن را از پا درآور • نارنجک و بشکه‌های قرمز منفجر می‌شوند • جعبه سفید = سلامتی، جعبه سبز = مهمات</p>
    </div>
  );
}

function Header({ title, onBack }: { title: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-3 mb-3 relative z-10">
      <button onClick={onBack} className="bg-black/60 border border-white/20 rounded-lg px-4 py-2 font-bold">→ بازگشت</button>
      <h2 className="text-3xl font-black text-yellow-400">{title}</h2>
    </div>
  );
}

function Stat({ label, v }: { label: string; v: number }) {
  return (
    <div className="flex items-center gap-2 text-xs">
      <span className="w-20 text-white/70">{label}</span>
      <div className="flex-1 h-1.5 bg-white/15 rounded"><div className="h-full bg-white rounded" style={{ width: `${Math.min(100, v)}%` }} /></div>
      <span className="w-7 text-left">{fa(Math.round(v))}</span>
    </div>
  );
}

function Armory({ loadout, setLoadout, onBack }: { loadout: { primary: string; secondary: string }; setLoadout: (l: { primary: string; secondary: string }) => void; onBack: () => void }) {
  const [sel, setSel] = useState(loadout.primary);
  const w = getWeapon(sel);
  const isSecondary = w.type === 'کلت';
  const equipped = loadout.primary === sel || loadout.secondary === sel;
  return (
    <div className="absolute inset-0 flex flex-col p-4 bg-black/40">
      <Header title="زرادخانه" onBack={onBack} />
      <div className="flex-1 flex gap-4 min-h-0">
        <div className="w-[34%] overflow-y-auto pr-1 flex flex-col gap-1.5">
          {WEAPONS.map((x) => (
            <button key={x.id} onClick={() => { setSel(x.id); audio.click(); }} className={`text-right rounded-lg px-3 py-2 border ${sel === x.id ? 'bg-yellow-400/90 text-black border-yellow-200' : 'bg-black/60 border-white/10'}`}>
              <div className="font-bold text-sm">{x.name}</div>
              <div className={`text-[10px] ${sel === x.id ? 'text-black/70' : 'text-white/50'}`}>{x.type} {(loadout.primary === x.id || loadout.secondary === x.id) && '• مجهز ✓'}</div>
            </button>
          ))}
        </div>
        <div className="flex-1 flex flex-col justify-between">
          <div className="flex-1 flex items-center justify-center">
            <GunArt w={w} />
          </div>
          <div className="bg-zinc-900/85 border border-white/15 rounded-xl p-4">
            <div className="flex justify-between items-center mb-2">
              <div>
                <div className="text-2xl font-black">{w.name}</div>
                <div className="text-xs text-yellow-300">{w.type}</div>
              </div>
              <button
                disabled={equipped}
                onClick={() => { audio.pickup(); setLoadout(isSecondary ? { ...loadout, secondary: sel } : { ...loadout, primary: sel }); }}
                className={`px-6 py-2 rounded-lg font-black ${equipped ? 'bg-green-600/60' : 'bg-yellow-400 text-black'}`}
              >{equipped ? 'مجهز شد ✓' : isSecondary ? 'تجهیز (سلاح دوم)' : 'تجهیز (سلاح اصلی)'}</button>
            </div>
            <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
              <Stat label="آسیب" v={Math.min(100, w.damage * (w.pellets ?? 1) * 0.7)} />
              <Stat label="سرعت شلیک" v={w.fireRate * 6} />
              <Stat label="دقت" v={100 - w.spread * 1000} />
              <Stat label="تحرک" v={w.mobility} />
              <Stat label="برد" v={w.range / 2.5} />
              <Stat label="ظرفیت خشاب" v={w.mag} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function GunArt({ w }: { w: Weapon }) {
  const col = '#' + w.color.toString(16).padStart(6, '0');
  const pistol = w.sound === 'pistol';
  const L = pistol ? 140 : w.sound === 'sniper' ? 380 : w.sound === 'smg' ? 230 : 310;
  return (
    <svg viewBox="0 0 420 180" className="w-full max-w-lg drop-shadow-[0_10px_20px_rgba(0,0,0,0.8)]">
      <g transform={`translate(${(420 - L - 40) / 2},40)`}>
        {!pistol && <path d={`M${L - 10},30 L${L + 40},28 L${L + 45},70 L${L + 25},72 L${L},50 Z`} fill={col} stroke="#000" strokeWidth="2" />}
        <rect x="0" y="34" width={L * 0.35} height="7" fill="#111" />
        <rect x={L * 0.25} y="22" width={L * 0.78} height="32" rx="4" fill={col} stroke="#000" strokeWidth="2" />
        <rect x={L * 0.25} y="26" width={L * 0.35} height="24" fill={w.id === 'ak' ? '#6a4020' : '#1a1a1a'} />
        {!pistol && <path d={`M${L * 0.55},54 l12,0 l${w.id === 'ak' || w.id === 'type25' ? 14 : 4},${Math.min(60, 30 + w.mag / 3)} l-14,4 Z`} fill="#151515" />}
        <path d={`M${L * 0.85},54 l14,0 l6,38 l-14,0 Z`} fill="#111" />
        {w.zoom >= 3 && <rect x={L * 0.45} y="4" width={L * 0.3} height="14" rx="7" fill="#111" />}
        {w.zoom < 3 && !pistol && <rect x={L * 0.62} y="12" width="20" height="10" fill="#222" />}
        {w.pellets && <rect x={L * 0.3} y="56" width={L * 0.3} height="10" rx="3" fill="#5a3a1a" />}
      </g>
    </svg>
  );
}

function SettingsScreen({ settings, setSettings, cheats, setCheats, onBack }: { settings: Settings; setSettings: (s: Settings) => void; cheats: Cheats; setCheats: (c: Cheats) => void; onBack: () => void }) {
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; t: string } | null>(null);
  const submit = () => {
    const c = CODES[code.trim().replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))];
    if (!c) { setMsg({ ok: false, t: 'کد نامعتبر است ❌' }); audio.empty(); return; }
    const on = !cheats[c.key];
    setCheats({ ...cheats, [c.key]: on });
    setMsg({ ok: true, t: `${c.label} ${on ? 'فعال شد ✅' : 'غیرفعال شد'}` });
    audio.cheat();
    setCode('');
  };
  return (
    <div className="absolute inset-0 flex flex-col p-4 bg-black/60">
      <Header title="تنظیمات" onBack={onBack} />
      <div className="flex-1 grid grid-cols-2 gap-4 min-h-0 overflow-y-auto">
        <div className="bg-zinc-900/85 border border-white/15 rounded-xl p-4 flex flex-col gap-3">
          <h3 className="font-black text-yellow-300">🎮 کنترل و گرافیک</h3>
          <label className="text-sm">حساسیت لمس: {fa(Math.round(settings.sensitivity * 100))}٪
            <input type="range" min={0.3} max={2.5} step={0.05} value={settings.sensitivity} onChange={(e) => setSettings({ ...settings, sensitivity: +e.target.value })} className="w-full accent-yellow-400" />
          </label>
          <label className="text-sm">صدا: {fa(Math.round(settings.volume * 100))}٪
            <input type="range" min={0} max={1} step={0.05} value={settings.volume} onChange={(e) => { setSettings({ ...settings, volume: +e.target.value }); audio.setVolume(+e.target.value); }} className="w-full accent-yellow-400" />
          </label>
          <div className="text-sm">کیفیت گرافیک:
            <div className="flex gap-2 mt-1">
              {(['low', 'medium', 'high'] as const).map((q) => (
                <button key={q} onClick={() => setSettings({ ...settings, quality: q })} className={`flex-1 py-1.5 rounded-lg text-sm font-bold ${settings.quality === q ? 'bg-yellow-400 text-black' : 'bg-zinc-700'}`}>{q === 'low' ? 'پایین' : q === 'medium' ? 'متوسط' : 'بالا'}</button>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={() => { const m = !settings.music; setSettings({ ...settings, music: m }); audio.musicOn = m; if (m) audio.startMusic(); else audio.stopMusic(); }} className={`flex-1 py-1.5 rounded-lg text-sm font-bold ${settings.music ? 'bg-green-600' : 'bg-zinc-700'}`}>موسیقی: {settings.music ? 'روشن' : 'خاموش'}</button>
            <button onClick={() => setSettings({ ...settings, leftFire: !settings.leftFire })} className={`flex-1 py-1.5 rounded-lg text-sm font-bold ${settings.leftFire ? 'bg-green-600' : 'bg-zinc-700'}`}>دکمه شلیک چپ: {settings.leftFire ? 'روشن' : 'خاموش'}</button>
          </div>
          <div className="mt-auto rounded-xl bg-gradient-to-l from-amber-600/30 to-yellow-500/10 border border-yellow-500/40 p-3 text-center">
            <div className="text-xs text-white/60">سازنده</div>
            <div className="text-xl font-black text-yellow-300">محمد حسین محسن آبادی</div>
            <div className="text-[10px] text-white/50">بازی رزمنده • نسخه ۱.۰</div>
          </div>
        </div>
        <div className="bg-zinc-900/85 border border-fuchsia-500/30 rounded-xl p-4 flex flex-col gap-3">
          <h3 className="font-black text-fuchsia-300">🔐 کدهای مود</h3>
          <div className="flex gap-2">
            <input
              value={code}
              onChange={(e) => setCode(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && submit()}
              inputMode="numeric"
              maxLength={4}
              placeholder="کد را وارد کنید"
              className="flex-1 bg-black/60 border border-white/20 rounded-lg px-3 py-2 text-center text-xl tracking-[0.4em] outline-none focus:border-fuchsia-400"
            />
            <button onClick={submit} className="px-5 rounded-lg bg-fuchsia-600 font-black">ثبت</button>
          </div>
          {msg && <div className={`text-sm font-bold ${msg.ok ? 'text-green-400' : 'text-red-400'}`}>{msg.t}</div>}
          <div className="flex flex-col gap-2">
            {Object.entries(CODES).map(([k, c]) => (
              <div key={k} className={`flex items-center justify-between rounded-lg px-3 py-2 border ${cheats[c.key] ? 'bg-fuchsia-700/40 border-fuchsia-400' : 'bg-black/40 border-white/10'}`}>
                <div>
                  <div className="font-bold text-sm">{c.label}</div>
                  <div className="text-[10px] text-white/60">{c.desc}</div>
                </div>
                <span className={`text-xs font-bold px-2 py-0.5 rounded ${cheats[c.key] ? 'bg-green-500 text-black' : 'bg-zinc-700 text-white/60'}`}>{cheats[c.key] ? 'فعال' : 'غیرفعال'}</span>
              </div>
            ))}
          </div>
          <p className="text-[10px] text-white/50">برای غیرفعال کردن هر مود، همان کد را دوباره وارد کنید.</p>
        </div>
      </div>
    </div>
  );
}
