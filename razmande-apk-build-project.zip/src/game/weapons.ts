export interface Weapon {
  id: string;
  name: string;
  type: string;
  damage: number;
  fireRate: number; // shots per second
  mag: number;
  reserve: number;
  reload: number; // seconds
  spread: number;
  range: number;
  mobility: number;
  auto: boolean;
  pellets?: number;
  color: number;
  zoom: number;
  sound: 'rifle' | 'smg' | 'sniper' | 'shotgun' | 'pistol' | 'lmg';
}

export const WEAPONS: Weapon[] = [
  { id: 'ak', name: 'کلاشینکف AK-47', type: 'تفنگ تهاجمی', damage: 34, fireRate: 9, mag: 30, reserve: 180, reload: 2.2, spread: 0.022, range: 70, mobility: 60, auto: true, color: 0x5a3b22, zoom: 1.4, sound: 'rifle' },
  { id: 'm4', name: 'M4A1', type: 'تفنگ تهاجمی', damage: 28, fireRate: 11, mag: 30, reserve: 210, reload: 2.0, spread: 0.016, range: 75, mobility: 65, auto: true, color: 0x2b2b2b, zoom: 1.5, sound: 'rifle' },
  { id: 'type25', name: 'Type 25', type: 'تفنگ تهاجمی', damage: 30, fireRate: 12, mag: 30, reserve: 210, reload: 2.1, spread: 0.02, range: 60, mobility: 60, auto: true, color: 0x1e2226, zoom: 1.4, sound: 'rifle' },
  { id: 'mp5', name: 'MP5', type: 'مسلسل دستی', damage: 22, fireRate: 14, mag: 35, reserve: 245, reload: 1.7, spread: 0.028, range: 40, mobility: 85, auto: true, color: 0x222222, zoom: 1.25, sound: 'smg' },
  { id: 'uzi', name: 'یوزی UZI', type: 'مسلسل دستی', damage: 19, fireRate: 16, mag: 32, reserve: 256, reload: 1.6, spread: 0.035, range: 35, mobility: 90, auto: true, color: 0x333a33, zoom: 1.2, sound: 'smg' },
  { id: 'dsr', name: 'دراگانوف SVD', type: 'تک‌تیرانداز', damage: 95, fireRate: 1.4, mag: 10, reserve: 40, reload: 2.8, spread: 0.002, range: 200, mobility: 40, auto: false, color: 0x4a3420, zoom: 4, sound: 'sniper' },
  { id: 'awm', name: 'AWM', type: 'تک‌تیرانداز', damage: 150, fireRate: 0.8, mag: 5, reserve: 25, reload: 3.2, spread: 0.001, range: 250, mobility: 35, auto: false, color: 0x3b4a2a, zoom: 5, sound: 'sniper' },
  { id: 'shotgun', name: 'شاتگان R90', type: 'شاتگان', damage: 16, fireRate: 1.6, mag: 8, reserve: 48, reload: 2.6, spread: 0.08, range: 20, mobility: 70, auto: false, pellets: 9, color: 0x3a2a1a, zoom: 1.15, sound: 'shotgun' },
  { id: 'pkm', name: 'تیربار PKM', type: 'تیربار', damage: 32, fireRate: 10, mag: 100, reserve: 300, reload: 4.5, spread: 0.03, range: 70, mobility: 30, auto: true, color: 0x2a2a20, zoom: 1.3, sound: 'lmg' },
  { id: 'colt', name: 'کلت کمری', type: 'کلت', damage: 26, fireRate: 5, mag: 12, reserve: 96, reload: 1.3, spread: 0.018, range: 40, mobility: 95, auto: false, color: 0x1a1a1a, zoom: 1.2, sound: 'pistol' },
  { id: 'deagle', name: 'دزرت ایگل', type: 'کلت', damage: 55, fireRate: 2.5, mag: 7, reserve: 49, reload: 1.6, spread: 0.02, range: 50, mobility: 90, auto: false, color: 0x8a8a8a, zoom: 1.25, sound: 'pistol' },
];

export const getWeapon = (id: string) => WEAPONS.find((w) => w.id === id) ?? WEAPONS[0];
