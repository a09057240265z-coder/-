import * as THREE from 'three';
import { audio } from './audio';
import { getWeapon, WEAPONS, type Weapon } from './weapons';

export interface Cheats {
  infAmmo: boolean; // 1391
  god: boolean; // 1392
  power: boolean; // 1393
}

export interface HudState {
  hp: number;
  ammo: number;
  reserve: number;
  weaponName: string;
  weaponIndex: number;
  weaponNames: string[];
  kills: number;
  score: number;
  wave: number;
  enemiesLeft: number;
  reloading: boolean;
  grenades: number;
  aiming: boolean;
  scoped: boolean;
  time: number;
  over: boolean;
  win: boolean;
}

export interface EngineOptions {
  loadout: string[];
  cheats: Cheats;
  sensitivity: number;
  quality: 'low' | 'medium' | 'high';
  map: 'city' | 'desert';
  onHud: (s: HudState) => void;
  onEvent: (type: string, data?: any) => void;
}

interface Box { min: THREE.Vector3; max: THREE.Vector3; }

interface Enemy {
  group: THREE.Group;
  parts: THREE.Mesh[];
  head: THREE.Mesh;
  legL: THREE.Mesh;
  legR: THREE.Mesh;
  hp: number;
  dead: boolean;
  deadT: number;
  shootCd: number;
  losCd: number;
  hasLos: boolean;
  strafe: number;
  strafeT: number;
  speed: number;
  walkT: number;
  flash: THREE.Mesh;
  flashT: number;
}

interface Particle { mesh: THREE.Mesh; vel: THREE.Vector3; life: number; max: number; grav: number; grow?: number; }
interface Grenade { mesh: THREE.Mesh; vel: THREE.Vector3; t: number; }
interface Barrel { mesh: THREE.Mesh; hp: number; dead: boolean; box: Box; }
interface Pickup { mesh: THREE.Group; kind: 'hp' | 'ammo'; respawn: number; }

const KILL_TARGET = 50;

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void, repeat?: [number, number]) {
  const cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const c = cv.getContext('2d')!;
  draw(c);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (repeat) t.repeat.set(repeat[0], repeat[1]);
  t.anisotropy = 4;
  return t;
}

function noiseFill(c: CanvasRenderingContext2D, w: number, h: number, base: string, amount: number, n = 4000) {
  c.fillStyle = base; c.fillRect(0, 0, w, h);
  for (let i = 0; i < n; i++) {
    const v = Math.random() * amount;
    c.fillStyle = Math.random() > 0.5 ? `rgba(255,255,255,${v})` : `rgba(0,0,0,${v})`;
    c.fillRect(Math.random() * w, Math.random() * h, 2 + Math.random() * 3, 2 + Math.random() * 3);
  }
}

export class GameEngine {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  opts: EngineOptions;
  clock = new THREE.Clock();
  raf = 0;
  running = true;
  paused = false;

  // player
  pos = new THREE.Vector3(0, 0, 0);
  vel = new THREE.Vector3();
  yaw = 0;
  pitch = 0;
  onGround = true;
  hp = 100;
  kills = 0;
  score = 0;
  wave = 0;
  time = 0;
  grenades = 3;
  stepT = 0;
  bobT = 0;
  crouch = false;
  over = false;

  // input
  input = { mx: 0, my: 0, lookX: 0, lookY: 0, fire: false, aim: false, sprint: false };
  keys: Record<string, boolean> = {};

  // weapons
  loadout: Weapon[] = [];
  ammo: number[] = [];
  reserve: number[] = [];
  wIndex = 0;
  fireCd = 0;
  reloadT = 0;
  recoil = 0;
  firedThisPress = false;
  viewModel = new THREE.Group();
  vmMap: THREE.Group[] = [];
  muzzle!: THREE.Mesh;
  muzzleLight!: THREE.PointLight;
  muzzleT = 0;
  aimLerp = 0;

  // world
  boxes: Box[] = [];
  worldMeshes: THREE.Object3D[] = [];
  footprints: { x: number; z: number; w: number; d: number; c: string }[] = [];
  enemies: Enemy[] = [];
  particles: Particle[] = [];
  tracers: { line: THREE.Line; life: number }[] = [];
  grenadesLive: Grenade[] = [];
  barrels: Barrel[] = [];
  pickups: Pickup[] = [];
  fires: { light: THREE.PointLight; pos: THREE.Vector3; t: number }[] = [];
  toSpawn = 0;
  waveDelay = 2;
  ray = new THREE.Raycaster();
  minimap: HTMLCanvasElement | null = null;
  hudT = 0;
  shake = 0;
  mapSize = 110;

  // shared assets
  partGeo = new THREE.BoxGeometry(0.08, 0.08, 0.08);
  bloodMat = new THREE.MeshBasicMaterial({ color: 0xaa0000 });
  dustMat = new THREE.MeshBasicMaterial({ color: 0x9a8a70 });
  fireMat = new THREE.MeshBasicMaterial({ color: 0xff7a1a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false });
  smokeMat = new THREE.MeshBasicMaterial({ color: 0x333333, transparent: true, opacity: 0.5, depthWrite: false });
  enemyMats!: { body: THREE.Material; skin: THREE.Material; dark: THREE.Material; vest: THREE.Material };

  constructor(canvas: HTMLCanvasElement, opts: EngineOptions) {
    this.opts = opts;
    const q = opts.quality;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: q !== 'low', powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, q === 'high' ? 2 : q === 'medium' ? 1.3 : 0.9));
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
    this.renderer.shadowMap.enabled = q !== 'low';
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.05, 400);
    this.camera.rotation.order = 'YXZ';
    this.scene.add(this.camera);

    this.enemyMats = {
      body: new THREE.MeshStandardMaterial({ color: opts.map === 'desert' ? 0x6b5a3a : 0x3d4a35, roughness: 0.9 }),
      skin: new THREE.MeshStandardMaterial({ color: 0xc89a78, roughness: 0.8 }),
      dark: new THREE.MeshStandardMaterial({ color: 0x1a1a1a, roughness: 0.6 }),
      vest: new THREE.MeshStandardMaterial({ color: 0x2a2a22, roughness: 0.9 }),
    };

    this.loadout = opts.loadout.map(getWeapon);
    if (opts.cheats.power) {
      // 1393 unlocks every weapon
      const extra = WEAPONS.filter((w) => !this.loadout.includes(w)).slice(0, 4);
      this.loadout = [...this.loadout, ...extra];
    }
    this.ammo = this.loadout.map((w) => w.mag);
    this.reserve = this.loadout.map((w) => w.reserve);
    if (opts.cheats.power) this.grenades = 10;

    this.buildWorld();
    this.buildViewModels();
    this.bindKeys();
    window.addEventListener('resize', this.onResize);
    this.loop();
  }

  // ---------------- WORLD ----------------
  buildWorld() {
    const desert = this.opts.map === 'desert';
    const S = this.mapSize;
    const skyTop = desert ? '#6aa0d8' : '#4a5566';
    const skyBot = desert ? '#f0d6a8' : '#b8a890';
    const fogCol = desert ? 0xe8d2a8 : 0x9a948a;
    this.scene.fog = new THREE.Fog(fogCol, 30, 170);
    this.scene.background = new THREE.Color(fogCol);

    // sky dome
    const skyTex = canvasTex(4, 256, (c) => {
      const g = c.createLinearGradient(0, 0, 0, 256);
      g.addColorStop(0, skyTop); g.addColorStop(0.55, skyBot); g.addColorStop(1, skyBot);
      c.fillStyle = g; c.fillRect(0, 0, 4, 256);
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(300, 24, 16), new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false }));
    this.scene.add(sky);

    // lights
    this.scene.add(new THREE.HemisphereLight(desert ? 0xfff2d8 : 0xc8d0e0, desert ? 0x8a6a40 : 0x4a4038, 1.1));
    const sun = new THREE.DirectionalLight(desert ? 0xfff0d0 : 0xffe2c0, desert ? 2.6 : 1.8);
    sun.position.set(60, 90, 40);
    sun.castShadow = this.opts.quality !== 'low';
    const sz = this.opts.quality === 'high' ? 2048 : 1024;
    sun.shadow.mapSize.set(sz, sz);
    const sc = sun.shadow.camera;
    sc.left = -S; sc.right = S; sc.top = S; sc.bottom = -S; sc.far = 300;
    sun.shadow.bias = -0.0005;
    this.scene.add(sun);

    // ground
    const groundTex = canvasTex(512, 512, (c) => {
      noiseFill(c, 512, 512, desert ? '#c8a878' : '#6a665e', 0.12, 9000);
      if (!desert) {
        c.strokeStyle = 'rgba(0,0,0,0.25)';
        for (let i = 0; i < 30; i++) {
          c.beginPath(); c.moveTo(Math.random() * 512, Math.random() * 512);
          c.lineTo(Math.random() * 512, Math.random() * 512); c.stroke();
        }
      }
    }, [40, 40]);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(S * 2.6, S * 2.6), new THREE.MeshStandardMaterial({ map: groundTex, roughness: 1 }));
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.scene.add(ground);
    this.worldMeshes.push(ground);

    // roads
    const roadTex = canvasTex(256, 256, (c) => {
      noiseFill(c, 256, 256, desert ? '#8a7860' : '#3a3a3c', 0.1, 3000);
      c.fillStyle = desert ? 'rgba(255,255,255,0.15)' : '#d8c040';
      c.fillRect(124, 0, 8, 110);
    }, [1, 30]);
    const roadMat = new THREE.MeshStandardMaterial({ map: roadTex, roughness: 0.95 });
    for (const off of [-40, 0, 40]) {
      const r1 = new THREE.Mesh(new THREE.PlaneGeometry(10, S * 2.2), roadMat);
      r1.rotation.x = -Math.PI / 2; r1.position.set(off, 0.01, 0); r1.receiveShadow = true;
      this.scene.add(r1);
      const r2 = r1.clone(); r2.rotation.z = Math.PI / 2; r2.position.set(0, 0.012, off);
      this.scene.add(r2);
    }

    // building materials
    const palette = desert
      ? ['#c8b090', '#b89a78', '#d8c4a0', '#a88a68', '#c0a080']
      : ['#8a8278', '#9a8a70', '#7a7068', '#a89880', '#6a6a70', '#b0a090'];
    const bMats = palette.map((col) =>
      new THREE.MeshStandardMaterial({
        roughness: 0.95,
        map: canvasTex(256, 256, (c) => {
          noiseFill(c, 256, 256, col, 0.1, 2500);
          for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) {
            const lit = Math.random() > 0.85;
            c.fillStyle = lit ? '#e8c880' : Math.random() > 0.3 ? '#1e2228' : '#3a3530';
            c.fillRect(x * 64 + 16, y * 64 + 14, 32, 38);
            c.fillStyle = 'rgba(0,0,0,0.3)'; c.fillRect(x * 64 + 14, y * 64 + 52, 36, 4);
          }
        }),
      })
    );

    const rnd = (a: number, b: number) => a + Math.random() * (b - a);
    const isFree = (x: number, z: number, r: number) => {
      // keep roads & spawn free
      for (const off of [-40, 0, 40]) {
        if (Math.abs(x - off) < 5 + r) return false;
        if (Math.abs(z - off) < 5 + r) return false;
      }
      return this.boxes.every((b) => x + r < b.min.x - 1.2 || x - r > b.max.x + 1.2 || z + r < b.min.z - 1.2 || z - r > b.max.z + 1.2);
    };

    // buildings
    let tries = 0;
    let count = 0;
    while (count < 46 && tries < 900) {
      tries++;
      const w = rnd(7, 16), d = rnd(7, 16), h = rnd(6, desert ? 12 : 26);
      const x = rnd(-S + 8, S - 8), z = rnd(-S + 8, S - 8);
      if (!isFree(x, z, Math.max(w, d) / 2)) continue;
      const mat = bMats[Math.floor(Math.random() * bMats.length)].clone();
      mat.map = mat.map!.clone();
      mat.map!.repeat.set(Math.round(w / 4), Math.round(h / 4));
      mat.map!.needsUpdate = true;
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      m.position.set(x, h / 2, z);
      m.castShadow = m.receiveShadow = true;
      this.scene.add(m);
      // roof ledge
      const ledge = new THREE.Mesh(new THREE.BoxGeometry(w + 0.4, 0.5, d + 0.4), new THREE.MeshStandardMaterial({ color: 0x555048 }));
      ledge.position.set(x, h + 0.25, z); ledge.castShadow = true;
      this.scene.add(ledge);
      this.addSolid(m, palette[0] === '#c8b090' ? '#8a7558' : '#555');
      count++;
    }

    // containers
    const contCols = [0xb03020, 0x2a5a8a, 0x3a7a3a, 0xc08a20, 0x8a8a8a, 0x7a3a8a];
    const ribTex = canvasTex(128, 64, (c) => {
      c.fillStyle = '#fff'; c.fillRect(0, 0, 128, 64);
      for (let i = 0; i < 16; i++) { c.fillStyle = i % 2 ? 'rgba(0,0,0,0.25)' : 'rgba(255,255,255,0.1)'; c.fillRect(i * 8, 0, 4, 64); }
      for (let i = 0; i < 300; i++) { c.fillStyle = `rgba(80,40,20,${Math.random() * 0.3})`; c.fillRect(Math.random() * 128, Math.random() * 64, 3, 3); }
    }, [3, 1]);
    for (let i = 0, t = 0; i < 34 && t < 600; t++) {
      const rot = Math.random() > 0.5;
      const w = rot ? 2.5 : 6, d = rot ? 6 : 2.5;
      const x = rnd(-S + 4, S - 4), z = rnd(-S + 4, S - 4);
      if (Math.hypot(x, z) < 8 || !isFree(x, z, 3)) continue;
      const stack = Math.random() > 0.65 ? 2 : 1;
      for (let s = 0; s < stack; s++) {
        const m = new THREE.Mesh(new THREE.BoxGeometry(w, 2.6, d), new THREE.MeshStandardMaterial({ color: contCols[Math.floor(Math.random() * contCols.length)], map: ribTex, roughness: 0.7, metalness: 0.3 }));
        m.position.set(x, 1.3 + s * 2.6, z);
        m.castShadow = m.receiveShadow = true;
        this.scene.add(m);
        this.addSolid(m, '#7a4a3a');
      }
      i++;
    }

    // cars
    const carCols = [0x6a9a5a, 0xc8c8c0, 0xa83030, 0x3a5a9a, 0xd8a838, 0x2a2a2a];
    for (let i = 0, t = 0; i < 18 && t < 400; t++) {
      const onRoad = [-40, 0, 40][Math.floor(Math.random() * 3)];
      const alongX = Math.random() > 0.5;
      const x = alongX ? rnd(-S + 6, S - 6) : onRoad + (Math.random() > 0.5 ? 3.2 : -3.2);
      const z = alongX ? onRoad + (Math.random() > 0.5 ? 3.2 : -3.2) : rnd(-S + 6, S - 6);
      if (Math.hypot(x, z) < 10) continue;
      if (!this.boxes.every((b) => x + 3 < b.min.x || x - 3 > b.max.x || z + 3 < b.min.z || z - 3 > b.max.z)) continue;
      const car = this.makeCar(carCols[i % carCols.length]);
      car.position.set(x, 0, z);
      car.rotation.y = alongX ? Math.PI / 2 : 0;
      this.scene.add(car);
      car.updateMatrixWorld(true);
      const bb = new THREE.Box3().setFromObject(car);
      this.boxes.push({ min: bb.min.clone(), max: bb.max.clone() });
      car.traverse((o) => { if ((o as THREE.Mesh).isMesh) this.worldMeshes.push(o); });
      this.footprints.push({ x: (bb.min.x + bb.max.x) / 2, z: (bb.min.z + bb.max.z) / 2, w: bb.max.x - bb.min.x, d: bb.max.z - bb.min.z, c: '#999' });
      i++;
    }

    // sandbags / low walls
    const sandMat = new THREE.MeshStandardMaterial({ color: desert ? 0xa89068 : 0x8a7a5a, roughness: 1 });
    for (let i = 0, t = 0; i < 22 && t < 400; t++) {
      const x = rnd(-S + 4, S - 4), z = rnd(-S + 4, S - 4);
      if (Math.hypot(x, z) < 6 || !isFree(x, z, 2)) continue;
      const rot = Math.random() > 0.5;
      const m = new THREE.Mesh(new THREE.BoxGeometry(rot ? 0.8 : 4, 1.1, rot ? 4 : 0.8), sandMat);
      m.position.set(x, 0.55, z);
      m.castShadow = m.receiveShadow = true;
      this.scene.add(m);
      this.addSolid(m, '#6a5a40');
      i++;
    }

    // explosive barrels
    const barrelMat = new THREE.MeshStandardMaterial({ color: 0xa82a1a, roughness: 0.5, metalness: 0.4 });
    const barrelGeo = new THREE.CylinderGeometry(0.45, 0.45, 1.2, 12);
    for (let i = 0, t = 0; i < 24 && t < 400; t++) {
      const x = rnd(-S + 3, S - 3), z = rnd(-S + 3, S - 3);
      if (Math.hypot(x, z) < 6 || !isFree(x, z, 0.6)) continue;
      const m = new THREE.Mesh(barrelGeo, barrelMat);
      m.position.set(x, 0.6, z);
      m.castShadow = true;
      this.scene.add(m);
      const box = { min: new THREE.Vector3(x - 0.45, 0, z - 0.45), max: new THREE.Vector3(x + 0.45, 1.2, z + 0.45) };
      this.boxes.push(box);
      this.worldMeshes.push(m);
      const b: Barrel = { mesh: m, hp: 30, dead: false, box };
      m.userData.barrel = b;
      this.barrels.push(b);
      i++;
    }

    // fires (atmosphere)
    for (let i = 0; i < 6; i++) {
      const p = new THREE.Vector3(rnd(-S + 10, S - 10), 0.2, rnd(-S + 10, S - 10));
      const light = new THREE.PointLight(0xff7a2a, 30, 14, 2);
      light.position.copy(p).setY(1.5);
      this.scene.add(light);
      const debris = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.4, 1), new THREE.MeshStandardMaterial({ color: 0x1a1612 }));
      debris.position.copy(p);
      this.scene.add(debris);
      this.fires.push({ light, pos: p, t: Math.random() * 10 });
    }

    // pickups
    for (let i = 0; i < 8; i++) {
      for (let t = 0; t < 100; t++) {
        const x = rnd(-S + 6, S - 6), z = rnd(-S + 6, S - 6);
        if (!isFree(x, z, 1)) continue;
        const kind: 'hp' | 'ammo' = i % 2 ? 'hp' : 'ammo';
        const g = new THREE.Group();
        const crate = new THREE.Mesh(new THREE.BoxGeometry(0.8, 0.5, 0.6), new THREE.MeshStandardMaterial({ color: kind === 'hp' ? 0xeeeeee : 0x4a5a2a, emissive: kind === 'hp' ? 0x220000 : 0x111a00 }));
        g.add(crate);
        const mark = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.52, 0.1), new THREE.MeshBasicMaterial({ color: kind === 'hp' ? 0xdd0000 : 0xf0c020 }));
        mark.position.z = 0.26; g.add(mark);
        g.position.set(x, 0.5, z);
        this.scene.add(g);
        this.pickups.push({ mesh: g, kind, respawn: 0 });
        break;
      }
    }

    // map boundary walls
    const wallMat = new THREE.MeshStandardMaterial({ color: desert ? 0xb09870 : 0x5a5550, roughness: 1 });
    const L = S + 2;
    for (const [x, z, w, d] of [[0, -L, L * 2, 1], [0, L, L * 2, 1], [-L, 0, 1, L * 2], [L, 0, 1, L * 2]]) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, 5, d), wallMat);
      m.position.set(x, 2.5, z);
      m.receiveShadow = true;
      this.scene.add(m);
      this.addSolid(m, '#333');
    }

    // distant mountains for desert / skyline for city
    for (let i = 0; i < 40; i++) {
      const a = (i / 40) * Math.PI * 2;
      const r = 220 + Math.random() * 30;
      const h = desert ? rnd(20, 60) : rnd(20, 70);
      const m = new THREE.Mesh(
        desert ? new THREE.ConeGeometry(rnd(25, 45), h, 6) : new THREE.BoxGeometry(rnd(10, 25), h, rnd(10, 25)),
        new THREE.MeshBasicMaterial({ color: desert ? 0xc8a880 : 0x6a6a72, fog: true })
      );
      m.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r);
      this.scene.add(m);
    }
  }

  addSolid(m: THREE.Mesh, col: string) {
    m.updateMatrixWorld(true);
    const bb = new THREE.Box3().setFromObject(m);
    this.boxes.push({ min: bb.min.clone(), max: bb.max.clone() });
    this.worldMeshes.push(m);
    if (bb.max.y > 0.5 && bb.max.x - bb.min.x < 100)
      this.footprints.push({ x: (bb.min.x + bb.max.x) / 2, z: (bb.min.z + bb.max.z) / 2, w: bb.max.x - bb.min.x, d: bb.max.z - bb.min.z, c: col });
  }

  makeCar(color: number) {
    const g = new THREE.Group();
    const paint = new THREE.MeshStandardMaterial({ color, roughness: 0.4, metalness: 0.5 });
    const glass = new THREE.MeshStandardMaterial({ color: 0x1a2430, roughness: 0.1, metalness: 0.8 });
    const tire = new THREE.MeshStandardMaterial({ color: 0x111111 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.7, 4.2), paint);
    body.position.y = 0.65; body.castShadow = true; g.add(body);
    const cab = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.6, 2.2), glass);
    cab.position.set(0, 1.3, -0.2); cab.castShadow = true; g.add(cab);
    const roof = new THREE.Mesh(new THREE.BoxGeometry(1.62, 0.08, 1.9), paint);
    roof.position.set(0, 1.62, -0.2); g.add(roof);
    const wg = new THREE.CylinderGeometry(0.35, 0.35, 0.25, 12);
    for (const [x, z] of [[-0.85, 1.3], [0.85, 1.3], [-0.85, -1.3], [0.85, -1.3]]) {
      const w = new THREE.Mesh(wg, tire);
      w.rotation.z = Math.PI / 2; w.position.set(x, 0.35, z); g.add(w);
    }
    const lightM = new THREE.MeshBasicMaterial({ color: 0xffffcc });
    for (const x of [-0.6, 0.6]) {
      const l = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, 0.05), lightM);
      l.position.set(x, 0.75, 2.11); g.add(l);
    }
    return g;
  }

  // ---------------- VIEW MODELS ----------------
  buildViewModels() {
    const metal = (c: number) => new THREE.MeshStandardMaterial({ color: c, roughness: 0.45, metalness: 0.6 });
    const glove = new THREE.MeshStandardMaterial({ color: 0x3a3a2a, roughness: 0.9 });
    const sleeve = new THREE.MeshStandardMaterial({ color: this.opts.map === 'desert' ? 0x8a7450 : 0x4a5a3a, roughness: 0.9 });
    for (const w of this.loadout) {
      const g = new THREE.Group();
      const dark = metal(0x1a1a1a);
      const accent = metal(w.color);
      const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number) => {
        const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); g.add(m); return m;
      };
      const isPistol = w.sound === 'pistol';
      const len = isPistol ? 0.22 : w.sound === 'sniper' ? 0.75 : w.sound === 'smg' ? 0.38 : 0.55;
      add(new THREE.BoxGeometry(0.06, isPistol ? 0.08 : 0.09, len), accent, 0, 0, -len / 2);
      const barrel = add(new THREE.CylinderGeometry(0.012, 0.012, isPistol ? 0.06 : 0.3, 8), dark, 0, 0.015, -len - (isPistol ? 0.03 : 0.15));
      barrel.rotation.x = Math.PI / 2;
      if (!isPistol) {
        add(new THREE.BoxGeometry(0.05, 0.13, 0.06), dark, 0, -0.1, -len * 0.45).rotation.x = w.id === 'ak' || w.id === 'type25' ? 0.25 : 0.1; // mag
        add(new THREE.BoxGeometry(0.05, 0.08, 0.22), accent, 0, -0.01, 0.1); // stock
        add(new THREE.BoxGeometry(0.065, 0.06, len * 0.45), w.id === 'ak' ? metal(0x6a4020) : dark, 0, -0.015, -len * 0.8); // handguard
      }
      if (w.zoom >= 3) {
        const sc = add(new THREE.CylinderGeometry(0.025, 0.03, 0.28, 12), dark, 0, 0.075, -len * 0.45);
        sc.rotation.x = Math.PI / 2;
      } else if (!isPistol) {
        add(new THREE.BoxGeometry(0.04, 0.04, 0.08), dark, 0, 0.065, -len * 0.4); // red dot
      }
      if (w.pellets) add(new THREE.BoxGeometry(0.05, 0.05, 0.2), metal(0x5a3a1a), 0, -0.06, -len * 0.7);
      add(new THREE.BoxGeometry(0.04, 0.1, 0.05), dark, 0, -0.08, -0.02).rotation.x = 0.3; // grip
      // hands & sleeves
      add(new THREE.BoxGeometry(0.07, 0.07, 0.09), glove, 0.01, -0.07, 0.0);
      const arm = add(new THREE.BoxGeometry(0.09, 0.09, 0.4), sleeve, 0.04, -0.12, 0.2);
      arm.rotation.x = 0.3;
      if (!isPistol) {
        add(new THREE.BoxGeometry(0.07, 0.06, 0.09), glove, -0.01, -0.05, -len * 0.75);
        const arm2 = add(new THREE.BoxGeometry(0.09, 0.09, 0.45), sleeve, -0.12, -0.13, -len * 0.5 + 0.15);
        arm2.rotation.y = 0.6; arm2.rotation.x = 0.2;
      }
      g.userData.tip = -len - (isPistol ? 0.06 : 0.3);
      g.visible = false;
      this.viewModel.add(g);
      this.vmMap.push(g);
    }
    this.muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 6), new THREE.MeshBasicMaterial({ color: 0xffd080, transparent: true, blending: THREE.AdditiveBlending }));
    this.muzzle.scale.set(1, 1, 2.5);
    this.viewModel.add(this.muzzle);
    this.muzzleLight = new THREE.PointLight(0xffaa44, 0, 8);
    this.viewModel.add(this.muzzleLight);
    this.camera.add(this.viewModel);
    this.viewModel.position.set(0.22, -0.22, -0.35);
    this.switchWeapon(0);
  }

  switchWeapon(i: number) {
    if (i < 0 || i >= this.loadout.length) return;
    this.wIndex = i;
    this.reloadT = 0;
    this.vmMap.forEach((g, k) => (g.visible = k === i));
    const tip = this.vmMap[i].userData.tip as number;
    this.muzzle.position.set(0, 0.015, tip);
    this.muzzleLight.position.set(0, 0.015, tip);
    this.muzzle.visible = false;
    this.fireCd = 0.3;
    audio.click();
  }

  // ---------------- INPUT ----------------
  bindKeys() {
    window.addEventListener('keydown', this.onKey);
    window.addEventListener('keyup', this.onKey);
  }
  onKey = (e: KeyboardEvent) => {
    const down = e.type === 'keydown';
    this.keys[e.code] = down;
    if (down) {
      if (e.code === 'KeyR') this.reload();
      if (e.code === 'KeyG') this.throwGrenade();
      if (e.code === 'Space') this.jump();
      if (e.code === 'KeyC') this.crouch = !this.crouch;
      if (e.code.startsWith('Digit')) this.switchWeapon(parseInt(e.code.slice(5)) - 1);
    }
  };
  mouseLook(dx: number, dy: number) {
    this.input.lookX += dx;
    this.input.lookY += dy;
  }

  jump() {
    if (this.onGround && !this.over) { this.vel.y = 6.2; this.onGround = false; this.crouch = false; }
  }

  reload() {
    const i = this.wIndex, w = this.loadout[i];
    if (this.reloadT > 0 || this.ammo[i] >= w.mag) return;
    if (this.reserve[i] <= 0 && !this.opts.cheats.infAmmo) return;
    this.reloadT = w.reload;
    audio.reload();
  }

  nextWeapon() { this.switchWeapon((this.wIndex + 1) % this.loadout.length); }

  throwGrenade() {
    if (this.grenades <= 0 || this.over) return;
    if (!this.opts.cheats.infAmmo) this.grenades--;
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 8), new THREE.MeshStandardMaterial({ color: 0x3a4a2a }));
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    m.position.copy(this.camera.position).addScaledVector(dir, 0.6);
    this.scene.add(m);
    this.grenadesLive.push({ mesh: m, vel: dir.multiplyScalar(17).add(new THREE.Vector3(0, 4, 0)), t: 2.2 });
    audio.click();
  }

  // ---------------- ENEMIES ----------------
  spawnEnemy() {
    const S = this.mapSize;
    let x = 0, z = 0;
    for (let t = 0; t < 50; t++) {
      x = (Math.random() * 2 - 1) * (S - 5);
      z = (Math.random() * 2 - 1) * (S - 5);
      if (Math.hypot(x - this.pos.x, z - this.pos.z) < 35) continue;
      if (this.boxes.some((b) => x > b.min.x - 0.6 && x < b.max.x + 0.6 && z > b.min.z - 0.6 && z < b.max.z + 0.6)) continue;
      break;
    }
    const M = this.enemyMats;
    const g = new THREE.Group();
    const parts: THREE.Mesh[] = [];
    const mk = (geo: THREE.BufferGeometry, mat: THREE.Material, px: number, py: number, pz: number) => {
      const m = new THREE.Mesh(geo, mat); m.position.set(px, py, pz); m.castShadow = true; g.add(m); parts.push(m); return m;
    };
    mk(new THREE.BoxGeometry(0.55, 0.7, 0.3), M.body, 0, 1.15, 0);
    mk(new THREE.BoxGeometry(0.58, 0.45, 0.34), M.vest, 0, 1.2, 0);
    const head = mk(new THREE.BoxGeometry(0.26, 0.28, 0.26), M.skin, 0, 1.67, 0);
    mk(new THREE.BoxGeometry(0.3, 0.14, 0.3), M.dark, 0, 1.82, 0); // helmet
    mk(new THREE.BoxGeometry(0.22, 0.05, 0.02), M.dark, 0, 1.7, -0.135); // goggles
    const legL = mk(new THREE.BoxGeometry(0.2, 0.8, 0.22), M.body, -0.14, 0.4, 0);
    const legR = mk(new THREE.BoxGeometry(0.2, 0.8, 0.22), M.body, 0.14, 0.4, 0);
    mk(new THREE.BoxGeometry(0.15, 0.6, 0.15), M.body, -0.35, 1.15, -0.15).rotation.x = -0.9;
    mk(new THREE.BoxGeometry(0.15, 0.6, 0.15), M.body, 0.35, 1.15, -0.15).rotation.x = -1.1;
    mk(new THREE.BoxGeometry(0.07, 0.1, 0.8), M.dark, 0.1, 1.25, -0.45); // gun
    const flash = new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 6), new THREE.MeshBasicMaterial({ color: 0xffcc66, transparent: true, blending: THREE.AdditiveBlending }));
    flash.position.set(0.1, 1.25, -0.9); flash.visible = false; g.add(flash);
    head.userData.head = true;
    g.position.set(x, 0, z);
    this.scene.add(g);
    const e: Enemy = {
      group: g, parts, head, legL, legR, hp: 100 + this.wave * 8, dead: false, deadT: 0,
      shootCd: 1 + Math.random() * 2, losCd: Math.random() * 0.3, hasLos: false,
      strafe: 0, strafeT: 0, speed: 2.6 + Math.random() * 1.2, walkT: Math.random() * 6, flash, flashT: 0,
    };
    parts.forEach((p) => (p.userData.enemy = e));
    this.enemies.push(e);
  }

  damageEnemy(e: Enemy, dmg: number, head: boolean, from: THREE.Vector3) {
    if (e.dead) return;
    if (this.opts.cheats.power) dmg *= 5;
    e.hp -= head ? dmg * 2.2 : dmg;
    this.opts.onEvent('hit', { head });
    audio.hit();
    if (e.hp <= 0) {
      e.dead = true;
      e.deadT = 0;
      this.kills++;
      this.score += head ? 150 : 100;
      audio.kill();
      this.opts.onEvent('kill', { head, weapon: this.loadout[this.wIndex].name });
      const away = e.group.position.clone().sub(from).setY(0).normalize();
      e.group.userData.fallDir = away;
    }
  }

  // ---------------- COMBAT ----------------
  shoot() {
    const i = this.wIndex, w = this.loadout[i];
    if (this.fireCd > 0 || this.reloadT > 0) return;
    if (this.ammo[i] <= 0) {
      audio.empty();
      this.fireCd = 0.25;
      this.reload();
      return;
    }
    if (!this.opts.cheats.infAmmo) this.ammo[i]--;
    this.fireCd = 1 / w.fireRate;
    audio.shot(w.sound);
    this.muzzleT = 0.05;
    this.recoil = Math.min(this.recoil + (w.sound === 'sniper' ? 1 : 0.35), 1.2);
    this.shake = Math.max(this.shake, w.sound === 'sniper' || w.pellets ? 0.4 : 0.12);
    this.pitch += (w.sound === 'sniper' ? 0.03 : 0.008) * (this.input.aim ? 0.6 : 1);

    const origin = this.camera.getWorldPosition(new THREE.Vector3());
    const baseDir = new THREE.Vector3();
    this.camera.getWorldDirection(baseDir);
    const spreadMul = (this.input.aim ? 0.35 : 1) * (this.onGround ? 1 : 2.5) * (this.vel.lengthSq() > 4 ? 1.4 : 1);
    const pellets = w.pellets ?? 1;
    const targets = [...this.worldMeshes, ...this.enemies.filter((e) => !e.dead).flatMap((e) => e.parts)];
    for (let p = 0; p < pellets; p++) {
      const dir = baseDir.clone();
      const s = w.spread * spreadMul;
      dir.x += (Math.random() - 0.5) * s * 2;
      dir.y += (Math.random() - 0.5) * s * 2;
      dir.z += (Math.random() - 0.5) * s * 2;
      dir.normalize();
      this.ray.set(origin, dir);
      this.ray.far = w.range * 2;
      const hits = this.ray.intersectObjects(targets, false);
      let end = origin.clone().addScaledVector(dir, w.range * 2);
      if (hits.length) {
        const h = hits[0];
        end = h.point;
        const e = h.object.userData.enemy as Enemy | undefined;
        if (e) {
          const falloff = h.distance > w.range ? 0.6 : 1;
          this.damageEnemy(e, w.damage * falloff, !!h.object.userData.head, this.pos);
          this.burst(h.point, this.bloodMat, 6, 2);
        } else {
          const b = h.object.userData.barrel as Barrel | undefined;
          if (b) { b.hp -= w.damage; if (b.hp <= 0) this.explodeBarrel(b); }
          this.burst(h.point, this.dustMat, 5, 1.5);
        }
      }
      if (p < 3) this.tracer(this.muzzle.getWorldPosition(new THREE.Vector3()), end, 0xffe0a0);
    }
  }

  tracer(a: THREE.Vector3, b: THREE.Vector3, col: number) {
    const geo = new THREE.BufferGeometry().setFromPoints([a, b]);
    const line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: col, transparent: true, opacity: 0.7 }));
    this.scene.add(line);
    this.tracers.push({ line, life: 0.06 });
  }

  burst(p: THREE.Vector3, mat: THREE.Material, n: number, speed: number) {
    for (let i = 0; i < n; i++) {
      if (this.particles.length > 250) break;
      const m = new THREE.Mesh(this.partGeo, mat);
      m.position.copy(p);
      this.scene.add(m);
      this.particles.push({ mesh: m, vel: new THREE.Vector3((Math.random() - 0.5) * speed * 2, Math.random() * speed * 1.5, (Math.random() - 0.5) * speed * 2), life: 0.6, max: 0.6, grav: 9 });
    }
  }

  explosion(p: THREE.Vector3, radius: number, dmg: number) {
    audio.explosion();
    this.shake = 1;
    const fb = new THREE.Mesh(new THREE.SphereGeometry(1, 12, 12), this.fireMat.clone());
    fb.position.copy(p);
    this.scene.add(fb);
    this.particles.push({ mesh: fb, vel: new THREE.Vector3(), life: 0.5, max: 0.5, grav: 0, grow: radius * 1.2 });
    for (let i = 0; i < 10; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.6, 6, 6), this.smokeMat.clone());
      s.position.copy(p).add(new THREE.Vector3((Math.random() - 0.5) * 2, Math.random(), (Math.random() - 0.5) * 2));
      this.scene.add(s);
      this.particles.push({ mesh: s, vel: new THREE.Vector3((Math.random() - 0.5) * 2, 2 + Math.random() * 2, (Math.random() - 0.5) * 2), life: 2, max: 2, grav: -0.5, grow: 2.5 });
    }
    const l = new THREE.PointLight(0xff8833, 200, radius * 4);
    l.position.copy(p).setY(p.y + 1);
    this.scene.add(l);
    setTimeout(() => this.scene.remove(l), 180);
    this.burst(p, this.dustMat, 20, 6);
    for (const e of this.enemies) {
      if (e.dead) continue;
      const d = e.group.position.distanceTo(p);
      if (d < radius) this.damageEnemy(e, dmg * (1 - d / radius) + 20, false, p);
    }
    const pd = this.pos.distanceTo(p);
    if (pd < radius) this.hurtPlayer(dmg * 0.6 * (1 - pd / radius), p);
    for (const b of this.barrels) {
      if (!b.dead && b.mesh.position.distanceTo(p) < radius * 0.8) setTimeout(() => this.explodeBarrel(b), 150);
    }
  }

  explodeBarrel(b: Barrel) {
    if (b.dead) return;
    b.dead = true;
    this.scene.remove(b.mesh);
    this.worldMeshes = this.worldMeshes.filter((m) => m !== b.mesh);
    this.boxes = this.boxes.filter((x) => x !== b.box);
    this.explosion(b.mesh.position.clone(), 7, 120);
    this.score += 25;
  }

  hurtPlayer(dmg: number, from: THREE.Vector3) {
    if (this.over || this.opts.cheats.god) return;
    this.hp -= dmg;
    audio.hurt();
    const dx = from.x - this.pos.x, dz = from.z - this.pos.z;
    const ang = Math.atan2(dx, dz) - Math.atan2(-Math.sin(this.yaw), -Math.cos(this.yaw));
    this.opts.onEvent('hurt', { angle: -ang });
    if (this.hp <= 0) {
      this.hp = 0;
      this.endGame(false);
    }
  }

  endGame(win: boolean) {
    this.over = true;
    this.input.fire = false;
    this.emitHud(win);
    this.opts.onEvent('over', { win, kills: this.kills, score: this.score, time: this.time });
  }

  hasLineOfSight(a: THREE.Vector3, b: THREE.Vector3) {
    const dir = b.clone().sub(a);
    const dist = dir.length();
    this.ray.set(a, dir.normalize());
    this.ray.far = dist;
    const hits = this.ray.intersectObjects(this.worldMeshes, false);
    return hits.length === 0 || hits[0].distance > dist - 0.3;
  }

  collide(p: THREE.Vector3, r: number, feet: number, height: number) {
    for (const b of this.boxes) {
      if (feet >= b.max.y - 0.45 || feet + height <= b.min.y) continue;
      const cx = Math.max(b.min.x, Math.min(p.x, b.max.x));
      const cz = Math.max(b.min.z, Math.min(p.z, b.max.z));
      const dx = p.x - cx, dz = p.z - cz;
      const d2 = dx * dx + dz * dz;
      if (d2 < r * r) {
        if (d2 > 0.000001) {
          const d = Math.sqrt(d2);
          p.x = cx + (dx / d) * r;
          p.z = cz + (dz / d) * r;
        } else {
          // inside: push to nearest face
          const opts = [p.x - b.min.x, b.max.x - p.x, p.z - b.min.z, b.max.z - p.z];
          const m = Math.min(...opts);
          if (m === opts[0]) p.x = b.min.x - r; else if (m === opts[1]) p.x = b.max.x + r;
          else if (m === opts[2]) p.z = b.min.z - r; else p.z = b.max.z + r;
        }
      }
    }
    const L = this.mapSize;
    p.x = Math.max(-L, Math.min(L, p.x));
    p.z = Math.max(-L, Math.min(L, p.z));
  }

  groundAt(x: number, z: number, feet: number, r = 0.3) {
    let g = 0;
    for (const b of this.boxes) {
      if (x + r > b.min.x && x - r < b.max.x && z + r > b.min.z && z - r < b.max.z && b.max.y <= feet + 0.5) g = Math.max(g, b.max.y);
    }
    return g;
  }

  // ---------------- LOOP ----------------
  loop = () => {
    this.raf = requestAnimationFrame(this.loop);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    if (this.paused) return;
    this.update(dt);
    this.renderer.render(this.scene, this.camera);
  };

  update(dt: number) {
    const ch = this.opts.cheats;
    if (!this.over) this.time += dt;

    // waves
    const alive = this.enemies.filter((e) => !e.dead).length;
    if (!this.over) {
      if (this.toSpawn === 0 && alive === 0) {
        this.waveDelay -= dt;
        if (this.waveDelay <= 0) {
          this.wave++;
          this.toSpawn = 4 + this.wave * 2;
          this.waveDelay = 4;
          this.opts.onEvent('wave', { wave: this.wave });
        }
      }
      if (this.toSpawn > 0 && alive < 6 + Math.min(this.wave, 6)) {
        this.spawnEnemy();
        this.toSpawn--;
      }
      if (this.kills >= KILL_TARGET) this.endGame(true);
    }

    // look
    const sens = 0.0042 * this.opts.sensitivity * (this.input.aim ? 0.55 / Math.sqrt(this.loadout[this.wIndex].zoom) : 1);
    this.yaw -= this.input.lookX * sens;
    this.pitch -= this.input.lookY * sens;
    this.input.lookX = this.input.lookY = 0;
    this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch));

    // movement
    const w = this.loadout[this.wIndex];
    let mx = this.input.mx, my = this.input.my;
    if (this.keys.KeyW) my = 1; if (this.keys.KeyS) my = -1;
    if (this.keys.KeyA) mx = -1; if (this.keys.KeyD) mx = 1;
    const sprint = (this.input.sprint || this.keys.ShiftLeft || my > 0.92) && my > 0.3 && !this.input.aim && !this.crouch;
    let speed = 5.2 * (0.7 + w.mobility / 330);
    if (sprint) speed *= 1.55;
    if (this.input.aim) speed *= 0.55;
    if (this.crouch) speed *= 0.5;
    if (ch.power) speed *= 1.4;
    const fx = -Math.sin(this.yaw), fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw), rz = -Math.sin(this.yaw);
    const len = Math.min(1, Math.hypot(mx, my));
    const ang = Math.atan2(mx, my);
    const tx = (fx * Math.cos(ang) + rx * Math.sin(ang)) * len * speed;
    const tz = (fz * Math.cos(ang) + rz * Math.sin(ang)) * len * speed;
    const accel = this.onGround ? 14 : 3;
    this.vel.x += (tx - this.vel.x) * Math.min(1, accel * dt);
    this.vel.z += (tz - this.vel.z) * Math.min(1, accel * dt);
    this.vel.y -= 18 * dt;
    if (this.over) { this.vel.x = this.vel.z = 0; }
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    this.collide(this.pos, 0.4, this.pos.y, 1.7);
    this.pos.y += this.vel.y * dt;
    const gY = this.groundAt(this.pos.x, this.pos.z, this.pos.y);
    if (this.pos.y <= gY) {
      if (!this.onGround && this.vel.y < -6) audio.step();
      this.pos.y = gY; this.vel.y = 0; this.onGround = true;
    } else if (this.pos.y > gY + 0.05) this.onGround = false;

    const hSpeed = Math.hypot(this.vel.x, this.vel.z);
    if (this.onGround && hSpeed > 1) {
      this.bobT += dt * hSpeed * 1.6;
      this.stepT -= dt * hSpeed;
      if (this.stepT <= 0) { audio.step(); this.stepT = 2.4; }
    }

    // camera
    const eye = this.crouch ? 1.05 : 1.62;
    this.shake = Math.max(0, this.shake - dt * 3);
    this.camera.position.set(
      this.pos.x + (Math.random() - 0.5) * this.shake * 0.1,
      this.pos.y + eye + Math.sin(this.bobT * 2) * 0.04 * Math.min(1, hSpeed / 5),
      this.pos.z + (Math.random() - 0.5) * this.shake * 0.1
    );
    this.camera.rotation.set(this.pitch + this.recoil * 0.02, this.yaw, 0);

    // aim / zoom
    this.aimLerp += ((this.input.aim ? 1 : 0) - this.aimLerp) * Math.min(1, dt * 12);
    const targetFov = 75 / (1 + (w.zoom - 1) * this.aimLerp);
    if (Math.abs(this.camera.fov - targetFov) > 0.05) { this.camera.fov = targetFov; this.camera.updateProjectionMatrix(); }
    const scoped = w.zoom >= 3 && this.aimLerp > 0.85;
    this.viewModel.visible = !scoped;
    const vb = Math.sin(this.bobT) * 0.012 * (1 - this.aimLerp);
    this.viewModel.position.set(
      THREE.MathUtils.lerp(0.22, 0, this.aimLerp) + vb,
      THREE.MathUtils.lerp(-0.22, -0.13, this.aimLerp) + Math.abs(Math.cos(this.bobT)) * 0.01 - (this.reloadT > 0 ? 0.15 : 0),
      THREE.MathUtils.lerp(-0.35, -0.28, this.aimLerp) + this.recoil * 0.06
    );
    this.viewModel.rotation.set(this.recoil * 0.15 + (this.reloadT > 0 ? -0.5 : 0), sprint ? 0.5 : 0, sprint ? 0.2 : 0);
    this.recoil = Math.max(0, this.recoil - dt * 5);

    // weapon fire
    this.fireCd -= dt;
    if (this.reloadT > 0) {
      this.reloadT -= dt;
      if (this.reloadT <= 0) {
        const i = this.wIndex;
        const need = w.mag - this.ammo[i];
        const take = ch.infAmmo ? need : Math.min(need, this.reserve[i]);
        this.ammo[i] += take;
        if (!ch.infAmmo) this.reserve[i] -= take;
        this.reloadT = 0;
      }
    }
    const firing = (this.input.fire || this.keys.Mouse0) && !this.over;
    if (firing) {
      if (w.auto || !this.firedThisPress) { this.shoot(); this.firedThisPress = true; }
    } else this.firedThisPress = false;
    if (this.muzzleT > 0) {
      this.muzzleT -= dt;
      this.muzzle.visible = true;
      this.muzzle.rotation.z = Math.random() * 6;
      this.muzzleLight.intensity = 6;
    } else { this.muzzle.visible = false; this.muzzleLight.intensity = 0; }

    // enemies
    const eyePos = this.camera.position.clone();
    for (const e of this.enemies) {
      const g = e.group;
      if (e.dead) {
        e.deadT += dt;
        const fd = g.userData.fallDir as THREE.Vector3 | undefined;
        if (e.deadT < 0.5) {
          g.rotation.x = -Math.min(1, e.deadT * 2.4) * Math.PI / 2 * (fd ? 1 : 1);
          if (fd) g.position.addScaledVector(fd, dt * 2);
        }
        if (e.deadT > 4) g.position.y -= dt * 0.5;
        continue;
      }
      const toP = new THREE.Vector3(this.pos.x - g.position.x, 0, this.pos.z - g.position.z);
      const dist = toP.length();
      toP.normalize();
      e.losCd -= dt;
      if (e.losCd <= 0) {
        e.losCd = 0.35;
        e.hasLos = dist < 90 && this.hasLineOfSight(g.position.clone().setY(1.6), eyePos);
      }
      g.rotation.y = Math.atan2(-toP.x, -toP.z);
      e.strafeT -= dt;
      if (e.strafeT <= 0) { e.strafeT = 1 + Math.random() * 2; e.strafe = Math.random() < 0.5 ? -1 : Math.random() < 0.5 ? 1 : 0; }
      let move = new THREE.Vector3();
      if (!e.hasLos || dist > 22) move.add(toP);
      else if (dist < 8) move.sub(toP.clone().multiplyScalar(0.5));
      if (e.hasLos) move.add(new THREE.Vector3(-toP.z, 0, toP.x).multiplyScalar(e.strafe * 0.7));
      if (move.lengthSq() > 0) {
        move.normalize().multiplyScalar(e.speed * dt);
        g.position.add(move);
        this.collide(g.position, 0.4, 0, 1.8);
        e.walkT += dt * 8;
        e.legL.rotation.x = Math.sin(e.walkT) * 0.6;
        e.legR.rotation.x = -Math.sin(e.walkT) * 0.6;
      }
      // shoot player
      e.shootCd -= dt;
      if (e.flashT > 0) { e.flashT -= dt; e.flash.visible = true; } else e.flash.visible = false;
      if (e.hasLos && dist < 70 && e.shootCd <= 0 && !this.over) {
        e.shootCd = 0.35 + Math.random() * 0.6;
        e.flashT = 0.05;
        const vol = Math.max(0.08, 1 - dist / 80) * 0.6;
        const pan = -toP.x * Math.cos(this.yaw) + toP.z * Math.sin(this.yaw);
        audio.shot('rifle', vol, Math.max(-1, Math.min(1, pan)));
        const hitChance = Math.max(0.08, 0.55 - dist / 120) * (this.crouch ? 0.7 : 1) * (hSpeed > 4 ? 0.7 : 1);
        const from = g.position.clone().setY(1.25);
        if (Math.random() < hitChance) {
          this.hurtPlayer(5 + Math.random() * 5 + this.wave * 0.4, g.position);
          this.tracer(from, eyePos.clone().add(new THREE.Vector3(0, -0.3, 0)), 0xffaa66);
        } else {
          const miss = eyePos.clone().add(new THREE.Vector3((Math.random() - 0.5) * 3, (Math.random() - 0.5) * 2, (Math.random() - 0.5) * 3));
          this.tracer(from, miss, 0xffaa66);
        }
      }
    }
    // cleanup old dead
    this.enemies = this.enemies.filter((e) => {
      if (e.dead && e.deadT > 6) { this.scene.remove(e.group); return false; }
      return true;
    });

    // grenades
    for (const gr of this.grenadesLive) {
      gr.t -= dt;
      gr.vel.y -= 18 * dt;
      gr.mesh.position.addScaledVector(gr.vel, dt);
      const gy = this.groundAt(gr.mesh.position.x, gr.mesh.position.z, gr.mesh.position.y, 0.1) + 0.1;
      if (gr.mesh.position.y < gy) { gr.mesh.position.y = gy; gr.vel.y *= -0.35; gr.vel.x *= 0.6; gr.vel.z *= 0.6; }
      const before = gr.mesh.position.clone();
      this.collide(gr.mesh.position, 0.1, gr.mesh.position.y, 0.2);
      if (!before.equals(gr.mesh.position)) { gr.vel.x *= -0.5; gr.vel.z *= -0.5; }
      if (gr.t <= 0) { this.scene.remove(gr.mesh); this.explosion(gr.mesh.position.clone(), 9, 160); }
    }
    this.grenadesLive = this.grenadesLive.filter((g) => g.t > 0);

    // particles
    for (const p of this.particles) {
      p.life -= dt;
      p.vel.y -= p.grav * dt;
      p.mesh.position.addScaledVector(p.vel, dt);
      if (p.grow) {
        const k = 1 + (1 - p.life / p.max) * p.grow;
        p.mesh.scale.setScalar(k);
        (p.mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, p.life / p.max) * 0.8;
      }
      if (p.mesh.position.y < 0.02 && !p.grow) { p.mesh.position.y = 0.02; p.vel.set(0, 0, 0); }
    }
    this.particles = this.particles.filter((p) => {
      if (p.life <= 0) { this.scene.remove(p.mesh); return false; }
      return true;
    });
    for (const t of this.tracers) t.life -= dt;
    this.tracers = this.tracers.filter((t) => {
      if (t.life <= 0) { this.scene.remove(t.line); t.line.geometry.dispose(); return false; }
      return true;
    });

    // fires
    for (const f of this.fires) {
      f.t += dt;
      f.light.intensity = 25 + Math.sin(f.t * 17) * 8 + Math.random() * 8;
      if (Math.random() < dt * 25 && this.particles.length < 240) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(0.25, 5, 5), Math.random() < 0.7 ? this.fireMat.clone() : this.smokeMat.clone());
        m.position.copy(f.pos).add(new THREE.Vector3((Math.random() - 0.5) * 1.2, 0.2, (Math.random() - 0.5) * 1.2));
        this.scene.add(m);
        const smoke = (m.material as THREE.MeshBasicMaterial).color.getHex() === 0x333333;
        this.particles.push({ mesh: m, vel: new THREE.Vector3((Math.random() - 0.5) * 0.4, smoke ? 2.5 : 2, (Math.random() - 0.5) * 0.4), life: smoke ? 2.5 : 0.7, max: smoke ? 2.5 : 0.7, grav: 0, grow: smoke ? 4 : 0.5 });
      }
    }

    // pickups
    for (const pk of this.pickups) {
      if (pk.respawn > 0) { pk.respawn -= dt; pk.mesh.visible = pk.respawn <= 0; continue; }
      pk.mesh.rotation.y += dt;
      if (pk.mesh.position.distanceTo(new THREE.Vector3(this.pos.x, pk.mesh.position.y, this.pos.z)) < 1.3 && Math.abs(this.pos.y - 0) < 1.5) {
        if (pk.kind === 'hp') { if (this.hp >= 100) continue; this.hp = Math.min(100, this.hp + 50); }
        else { this.reserve = this.reserve.map((r, i) => r + this.loadout[i].mag * 2); this.grenades = Math.min(this.grenades + 1, 10); }
        pk.respawn = 25; pk.mesh.visible = false;
        audio.pickup();
        this.opts.onEvent('pickup', { kind: pk.kind });
      }
    }

    // regen health slowly
    if (!this.over && this.hp < 100 && this.hp > 0) this.hp = Math.min(100, this.hp + dt * 1.5);

    this.drawMinimap();
    this.hudT -= dt;
    if (this.hudT <= 0) { this.hudT = 0.08; this.emitHud(false); }
  }

  emitHud(win: boolean) {
    const w = this.loadout[this.wIndex];
    this.opts.onHud({
      hp: Math.ceil(this.hp), ammo: this.ammo[this.wIndex], reserve: this.reserve[this.wIndex],
      weaponName: w.name, weaponIndex: this.wIndex, weaponNames: this.loadout.map((x) => x.name),
      kills: this.kills, score: this.score, wave: this.wave,
      enemiesLeft: this.enemies.filter((e) => !e.dead).length + this.toSpawn,
      reloading: this.reloadT > 0, grenades: this.grenades, aiming: this.input.aim,
      scoped: w.zoom >= 3 && this.aimLerp > 0.85, time: this.time, over: this.over, win,
    });
  }

  drawMinimap() {
    const cv = this.minimap;
    if (!cv) return;
    const c = cv.getContext('2d')!;
    const W = cv.width, H = cv.height;
    const scale = 1.4;
    c.save();
    c.clearRect(0, 0, W, H);
    c.fillStyle = 'rgba(20,28,24,0.85)';
    c.fillRect(0, 0, W, H);
    c.translate(W / 2, H / 2);
    c.rotate(this.yaw);
    c.scale(scale, scale);
    c.translate(-this.pos.x, -this.pos.z);
    for (const f of this.footprints) {
      if (Math.abs(f.x - this.pos.x) > 70 || Math.abs(f.z - this.pos.z) > 70) continue;
      c.fillStyle = f.c;
      c.fillRect(f.x - f.w / 2, f.z - f.d / 2, f.w, f.d);
    }
    for (const e of this.enemies) {
      if (e.dead) continue;
      c.fillStyle = e.flashT > -0.5 && e.hasLos ? '#ff2a2a' : 'rgba(255,60,60,0.6)';
      c.beginPath(); c.arc(e.group.position.x, e.group.position.z, 2, 0, Math.PI * 2); c.fill();
    }
    for (const p of this.pickups) {
      if (!p.mesh.visible) continue;
      c.fillStyle = p.kind === 'hp' ? '#fff' : '#f0c020';
      c.fillRect(p.mesh.position.x - 1.2, p.mesh.position.z - 1.2, 2.4, 2.4);
    }
    c.restore();
    // player arrow
    c.fillStyle = '#ffd23a';
    c.beginPath(); c.moveTo(W / 2, H / 2 - 8); c.lineTo(W / 2 - 6, H / 2 + 6); c.lineTo(W / 2 + 6, H / 2 + 6); c.closePath(); c.fill();
    c.strokeStyle = 'rgba(255,255,255,0.4)'; c.lineWidth = 2; c.strokeRect(1, 1, W - 2, H - 2);
  }

  onResize = () => {
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight, false);
  };

  dispose() {
    cancelAnimationFrame(this.raf);
    window.removeEventListener('keydown', this.onKey);
    window.removeEventListener('keyup', this.onKey);
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
    this.scene.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
  }
}
