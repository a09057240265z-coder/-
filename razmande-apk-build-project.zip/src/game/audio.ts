// Procedural audio engine — all sounds synthesized with WebAudio (no files needed)
class AudioEngine {
  ctx: AudioContext | null = null;
  master: GainNode | null = null;
  noiseBuf: AudioBuffer | null = null;
  volume = 0.8;
  musicOn = true;
  musicNodes: { stop: () => void } | null = null;

  init() {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') this.ctx.resume();
      return;
    }
    const AC = window.AudioContext || (window as any).webkitAudioContext;
    this.ctx = new AC();
    this.master = this.ctx.createGain();
    this.master.gain.value = this.volume;
    this.master.connect(this.ctx.destination);
    const len = this.ctx.sampleRate * 2;
    this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }

  setVolume(v: number) {
    this.volume = v;
    if (this.master) this.master.gain.value = v;
  }

  private noise(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType = 'lowpass', delay = 0, pan = 0) {
    if (!this.ctx || !this.master || !this.noiseBuf) return;
    const t = this.ctx.currentTime + delay;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuf;
    src.playbackRate.value = 0.8 + Math.random() * 0.4;
    const f = this.ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t);
    f.frequency.exponentialRampToValueAtTime(Math.max(60, freq * 0.25), t + dur);
    f.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    const p = this.ctx.createStereoPanner();
    p.pan.value = pan;
    src.connect(f).connect(g).connect(p).connect(this.master);
    src.start(t, Math.random());
    src.stop(t + dur + 0.05);
  }

  private tone(freq: number, dur: number, gain: number, type: OscillatorType = 'sine', delay = 0, endFreq?: number) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (endFreq) o.frequency.exponentialRampToValueAtTime(endFreq, t + dur);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g).connect(this.master);
    o.start(t);
    o.stop(t + dur + 0.05);
  }

  shot(kind: string, distanceFactor = 1, pan = 0) {
    const v = distanceFactor;
    switch (kind) {
      case 'sniper':
        this.noise(0.9, 5000, 0.7, 1.0 * v, 'lowpass', 0, pan);
        this.tone(90, 0.5, 0.7 * v, 'sine', 0, 30);
        this.noise(1.4, 900, 0.5, 0.25 * v, 'lowpass', 0.08, pan);
        break;
      case 'shotgun':
        this.noise(0.6, 3500, 0.6, 1.0 * v, 'lowpass', 0, pan);
        this.tone(70, 0.35, 0.8 * v, 'sine', 0, 30);
        break;
      case 'pistol':
        this.noise(0.25, 4500, 1, 0.7 * v, 'lowpass', 0, pan);
        this.tone(160, 0.12, 0.4 * v, 'triangle', 0, 60);
        break;
      case 'smg':
        this.noise(0.18, 5000, 1, 0.55 * v, 'lowpass', 0, pan);
        this.tone(140, 0.08, 0.35 * v, 'square', 0, 60);
        break;
      case 'lmg':
        this.noise(0.35, 3000, 0.8, 0.8 * v, 'lowpass', 0, pan);
        this.tone(100, 0.15, 0.5 * v, 'sine', 0, 40);
        break;
      default:
        this.noise(0.32, 4000, 0.8, 0.75 * v, 'lowpass', 0, pan);
        this.tone(120, 0.14, 0.5 * v, 'sine', 0, 45);
    }
  }

  reload() {
    this.noise(0.08, 2500, 5, 0.4, 'bandpass', 0);
    this.tone(800, 0.05, 0.15, 'square', 0.02, 400);
    this.noise(0.08, 3000, 6, 0.5, 'bandpass', 0.55);
    this.tone(1200, 0.04, 0.2, 'square', 0.6, 500);
    this.noise(0.1, 2000, 4, 0.5, 'bandpass', 0.9);
  }
  empty() { this.tone(1500, 0.04, 0.2, 'square', 0, 900); }
  hit() { this.tone(1800, 0.06, 0.25, 'triangle', 0, 1200); }
  kill() {
    this.tone(1200, 0.08, 0.3, 'triangle');
    this.tone(1800, 0.12, 0.3, 'triangle', 0.07);
  }
  hurt() {
    this.noise(0.2, 800, 2, 0.6, 'lowpass');
    this.tone(200, 0.2, 0.3, 'sawtooth', 0, 80);
  }
  step() { this.noise(0.07, 600, 1.5, 0.12, 'lowpass'); }
  explosion() {
    this.noise(2, 1500, 0.5, 1.2, 'lowpass');
    this.tone(55, 1.2, 1.0, 'sine', 0, 20);
  }
  click() { this.tone(900, 0.05, 0.2, 'triangle', 0, 600); }
  cheat() {
    [523, 659, 784, 1046].forEach((f, i) => this.tone(f, 0.18, 0.25, 'square', i * 0.09));
  }
  pickup() {
    this.tone(660, 0.1, 0.25, 'triangle');
    this.tone(990, 0.15, 0.25, 'triangle', 0.08);
  }

  startMusic() {
    if (!this.ctx || !this.master || this.musicNodes || !this.musicOn) return;
    const ctx = this.ctx;
    const g = ctx.createGain();
    g.gain.value = 0.12;
    g.connect(this.master);
    const notes = [110, 110, 130.8, 98, 110, 146.8, 130.8, 98];
    let i = 0;
    let stopped = false;
    const tick = () => {
      if (stopped || !this.ctx) return;
      const t = ctx.currentTime;
      const o = ctx.createOscillator();
      o.type = 'sawtooth';
      o.frequency.value = notes[i % notes.length];
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = 600;
      const eg = ctx.createGain();
      eg.gain.setValueAtTime(0.6, t);
      eg.gain.exponentialRampToValueAtTime(0.01, t + 0.45);
      o.connect(f).connect(eg).connect(g);
      o.start(t);
      o.stop(t + 0.5);
      if (i % 2 === 0) {
        const k = ctx.createOscillator();
        k.frequency.setValueAtTime(120, t);
        k.frequency.exponentialRampToValueAtTime(40, t + 0.2);
        const kg = ctx.createGain();
        kg.gain.setValueAtTime(1, t);
        kg.gain.exponentialRampToValueAtTime(0.01, t + 0.25);
        k.connect(kg).connect(g);
        k.start(t);
        k.stop(t + 0.3);
      }
      i++;
    };
    const id = window.setInterval(tick, 260);
    this.musicNodes = {
      stop: () => {
        stopped = true;
        clearInterval(id);
        g.disconnect();
      },
    };
  }
  stopMusic() {
    this.musicNodes?.stop();
    this.musicNodes = null;
  }
}

export const audio = new AudioEngine();
