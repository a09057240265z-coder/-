import { useEffect, useRef, useState } from 'react';
import { GameEngine, type HudState, type Cheats } from '../game/Engine';
import { audio } from '../game/audio';

export interface Settings {
  sensitivity: number;
  quality: 'low' | 'medium' | 'high';
  volume: number;
  music: boolean;
  leftFire: boolean;
}

interface Props {
  loadout: string[];
  cheats: Cheats;
  settings: Settings;
  map: 'city' | 'desert';
  onExit: (result?: { kills: number; score: number }) => void;
}

interface Feed { id: number; text: string; head: boolean; }

const fa = (n: number) => n.toLocaleString('fa-IR');

export default function Game({ loadout, cheats, settings, map, onExit }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const miniRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);
  const [hud, setHud] = useState<HudState | null>(null);
  const [hit, setHit] = useState<{ head: boolean; t: number } | null>(null);
  const [hurts, setHurts] = useState<{ id: number; angle: number }[]>([]);
  const [feed, setFeed] = useState<Feed[]>([]);
  const [banner, setBanner] = useState<string | null>(null);
  const [paused, setPaused] = useState(false);
  const [over, setOver] = useState<{ win: boolean; kills: number; score: number; time: number } | null>(null);
  const [vignette, setVignette] = useState(0);
  const joy = useRef<{ id: number; ox: number; oy: number; x: number; y: number } | null>(null);
  const [joyUi, setJoyUi] = useState<{ ox: number; oy: number; x: number; y: number } | null>(null);
  const looks = useRef<Map<number, { x: number; y: number }>>(new Map());

  useEffect(() => {
    audio.init();
    audio.setVolume(settings.volume);
    audio.stopMusic();
    const eng = new GameEngine(canvasRef.current!, {
      loadout,
      cheats,
      sensitivity: settings.sensitivity,
      quality: settings.quality,
      map,
      onHud: setHud,
      onEvent: (type, data) => {
        if (type === 'hit') setHit({ head: data.head, t: Date.now() });
        if (type === 'hurt') {
          const id = Math.random();
          setHurts((h) => [...h.slice(-3), { id, angle: data.angle }]);
          setVignette(1);
          setTimeout(() => setHurts((h) => h.filter((x) => x.id !== id)), 900);
        }
        if (type === 'kill') {
          const id = Math.random();
          setFeed((f) => [...f.slice(-4), { id, text: `رزمنده ⟵ [${data.weapon}] ⟵ دشمن`, head: data.head }]);
          setTimeout(() => setFeed((f) => f.filter((x) => x.id !== id)), 4000);
        }
        if (type === 'wave') {
          setBanner(`موج ${fa(data.wave)}`);
          setTimeout(() => setBanner(null), 2200);
        }
        if (type === 'pickup') {
          setBanner(data.kind === 'hp' ? '+ سلامتی' : '+ مهمات');
          setTimeout(() => setBanner(null), 1000);
        }
        if (type === 'over') setOver(data);
      },
    });
    eng.minimap = miniRef.current;
    engineRef.current = eng;
    (window as any).__eng = eng;

    // desktop mouse
    const canvas = canvasRef.current!;
    const onMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === canvas) eng.mouseLook(e.movementX * 0.6, e.movementY * 0.6);
    };
    const onMouseDown = (e: MouseEvent) => {
      if (document.pointerLockElement !== canvas) return;
      if (e.button === 0) eng.input.fire = true;
      if (e.button === 2) eng.input.aim = true;
    };
    const onMouseUp = (e: MouseEvent) => {
      if (e.button === 0) eng.input.fire = false;
      if (e.button === 2) eng.input.aim = false;
    };
    const ctx = (e: Event) => e.preventDefault();
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    window.addEventListener('contextmenu', ctx);
    return () => {
      eng.dispose();
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      window.removeEventListener('contextmenu', ctx);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (vignette <= 0) return;
    const t = setTimeout(() => setVignette((v) => Math.max(0, v - 0.1)), 50);
    return () => clearTimeout(t);
  }, [vignette]);

  useEffect(() => {
    if (engineRef.current) engineRef.current.paused = paused;
  }, [paused]);

  const eng = () => engineRef.current!;

  // ---- touch: look area + joystick ----
  const onAreaDown = (e: React.PointerEvent) => {
    if (e.pointerType === 'mouse') {
      canvasRef.current?.requestPointerLock?.();
      return;
    }
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
    if (e.clientX < window.innerWidth * 0.4 && !joy.current) {
      joy.current = { id: e.pointerId, ox: e.clientX, oy: e.clientY, x: e.clientX, y: e.clientY };
      setJoyUi({ ...joy.current });
    } else {
      looks.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }
  };
  const onAreaMove = (e: React.PointerEvent) => {
    const j = joy.current;
    if (j && j.id === e.pointerId) {
      let dx = e.clientX - j.ox, dy = e.clientY - j.oy;
      const d = Math.hypot(dx, dy), R = 55;
      if (d > R) { dx = (dx / d) * R; dy = (dy / d) * R; }
      j.x = j.ox + dx; j.y = j.oy + dy;
      eng().input.mx = dx / R;
      eng().input.my = -dy / R;
      eng().input.sprint = d > R * 1.6 && -dy > R * 0.7;
      setJoyUi({ ...j });
      return;
    }
    const l = looks.current.get(e.pointerId);
    if (l) {
      eng().mouseLook(e.clientX - l.x, e.clientY - l.y);
      l.x = e.clientX; l.y = e.clientY;
    }
  };
  const onAreaUp = (e: React.PointerEvent) => {
    if (joy.current?.id === e.pointerId) {
      joy.current = null;
      setJoyUi(null);
      eng().input.mx = eng().input.my = 0;
      eng().input.sprint = false;
    }
    looks.current.delete(e.pointerId);
  };

  // fire button that also allows looking while held (COD-mobile style)
  const fireHandlers = () => {
    let last: { x: number; y: number } | null = null;
    return {
      onPointerDown: (e: React.PointerEvent) => {
        e.stopPropagation();
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
        last = { x: e.clientX, y: e.clientY };
        eng().input.fire = true;
      },
      onPointerMove: (e: React.PointerEvent) => {
        if (!last) return;
        eng().mouseLook(e.clientX - last.x, e.clientY - last.y);
        last = { x: e.clientX, y: e.clientY };
      },
      onPointerUp: () => { last = null; eng().input.fire = false; },
      onPointerCancel: () => { last = null; eng().input.fire = false; },
    };
  };
  const fireR = useRef(fireHandlers()).current;
  const fireL = useRef(fireHandlers()).current;

  const tap = (fn: () => void) => ({
    onPointerDown: (e: React.PointerEvent) => { e.stopPropagation(); fn(); },
  });

  const hpColor = !hud ? '#fff' : hud.hp > 60 ? '#5ee05e' : hud.hp > 30 ? '#f0c020' : '#ff3a3a';
  const showHit = hit && Date.now() - hit.t < 180;
  const fmtTime = (t: number) => `${fa(Math.floor(t / 60))}:${Math.floor(t % 60).toString().padStart(2, '0').replace(/\d/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[+d])}`;

  return (
    <div className="fixed inset-0 bg-black select-none overflow-hidden touch-none" dir="rtl">
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />

      {/* touch area */}
      <div
        className="absolute inset-0"
        onPointerDown={onAreaDown}
        onPointerMove={onAreaMove}
        onPointerUp={onAreaUp}
        onPointerCancel={onAreaUp}
      />

      {/* damage vignette */}
      <div className="pointer-events-none absolute inset-0" style={{ boxShadow: `inset 0 0 ${120 + vignette * 80}px rgba(200,0,0,${vignette * 0.7 + (hud && hud.hp < 30 ? 0.35 : 0)})` }} />

      {/* scope overlay */}
      {hud?.scoped && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="absolute inset-0" style={{ background: 'radial-gradient(circle at center, transparent 0, transparent 38vh, #000 38.3vh)' }} />
          <div className="absolute w-px h-[76vh] bg-black" />
          <div className="absolute h-px w-[76vh] bg-black" />
          <div className="absolute w-2 h-2 rounded-full bg-red-600" />
        </div>
      )}

      {/* crosshair */}
      {!hud?.scoped && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
          <div className={`relative transition-all ${hud?.aiming ? 'w-4 h-4' : 'w-10 h-10'}`}>
            <span className="absolute left-1/2 top-0 w-0.5 h-2.5 -translate-x-1/2 bg-white/90 shadow" />
            <span className="absolute left-1/2 bottom-0 w-0.5 h-2.5 -translate-x-1/2 bg-white/90 shadow" />
            <span className="absolute top-1/2 left-0 h-0.5 w-2.5 -translate-y-1/2 bg-white/90 shadow" />
            <span className="absolute top-1/2 right-0 h-0.5 w-2.5 -translate-y-1/2 bg-white/90 shadow" />
          </div>
        </div>
      )}
      {showHit && (
        <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 text-3xl font-black" style={{ color: hit!.head ? '#ff3030' : '#fff' }}>✕</div>
      )}

      {/* hurt indicators */}
      {hurts.map((h) => (
        <div key={h.id} className="pointer-events-none absolute left-1/2 top-1/2 w-0 h-0" style={{ transform: `rotate(${h.angle}rad)` }}>
          <div className="absolute -left-10 -top-[150px] w-20 h-8 rounded-[50%] border-t-8 border-red-600/80 animate-pulse" />
        </div>
      ))}

      {/* top-left: score panel */}
      <div className="pointer-events-none absolute top-2 right-2 flex items-center gap-2">
        <div className="bg-black/50 border border-white/20 rounded-lg px-3 py-1 text-white text-sm leading-tight">
          <div className="flex gap-3 items-center">
            <span className="text-yellow-400 font-black">هدف: {fa(50)}</span>
            <span>کشته: <b className="text-green-400">{fa(hud?.kills ?? 0)}</b></span>
            <span>امتیاز: <b>{fa(hud?.score ?? 0)}</b></span>
          </div>
          <div className="flex gap-3 text-xs text-white/80">
            <span>موج {fa(hud?.wave ?? 0)}</span>
            <span>دشمن باقیمانده: {fa(hud?.enemiesLeft ?? 0)}</span>
            <span>⏱ {fmtTime(hud?.time ?? 0)}</span>
          </div>
        </div>
        {(cheats.infAmmo || cheats.god || cheats.power) && (
          <div className="bg-fuchsia-700/70 rounded px-2 py-1 text-[10px] text-white font-bold">
            مود فعال {cheats.infAmmo && '∞'} {cheats.god && '🛡'} {cheats.power && '⚡'}
          </div>
        )}
      </div>

      {/* minimap */}
      <canvas ref={miniRef} width={150} height={150} className="pointer-events-none absolute top-2 left-2 w-[24vh] h-[24vh] max-w-[150px] max-h-[150px] rounded-md" />

      {/* kill feed */}
      <div className="pointer-events-none absolute top-[28vh] left-2 flex flex-col gap-1 items-start" dir="rtl">
        {feed.map((f) => (
          <div key={f.id} className="bg-black/50 text-white text-xs px-2 py-0.5 rounded">
            {f.text} {f.head && <span className="text-red-400">🎯 هدشات</span>}
          </div>
        ))}
      </div>

      {banner && (
        <div className="pointer-events-none absolute top-[22%] left-1/2 -translate-x-1/2 text-yellow-300 text-3xl font-black drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] animate-pulse">{banner}</div>
      )}

      {/* bottom center HP + weapons */}
      <div className="pointer-events-none absolute bottom-2 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 w-[42vw]">
        <div className="flex gap-1">
          {hud?.weaponNames.map((n, i) => (
            <div key={i} className={`px-2 py-0.5 text-[10px] rounded border ${i === hud.weaponIndex ? 'bg-yellow-400 text-black border-yellow-200 font-bold' : 'bg-black/50 text-white/70 border-white/20'}`}>{n}</div>
          ))}
        </div>
        <div className="flex items-center gap-2 w-full">
          <span className="text-white text-xs font-bold w-8">{fa(hud?.hp ?? 100)}</span>
          <div className="flex-1 h-2 bg-black/60 rounded overflow-hidden border border-white/20">
            <div className="h-full transition-all" style={{ width: `${hud?.hp ?? 100}%`, background: hpColor }} />
          </div>
          <span className="text-white text-xs">❤</span>
        </div>
      </div>

      {/* ammo */}
      <div className="pointer-events-none absolute bottom-[38vh] right-3 text-white text-right">
        <div className="text-[11px] text-white/80">{hud?.weaponName}</div>
        <div className="text-2xl font-black">
          <span className={hud && hud.ammo <= 5 ? 'text-red-400' : ''}>{cheats.infAmmo ? '∞' : fa(hud?.ammo ?? 0)}</span>
          <span className="text-sm text-white/60"> / {cheats.infAmmo ? '∞' : fa(hud?.reserve ?? 0)}</span>
        </div>
        {hud?.reloading && <div className="text-yellow-300 text-xs animate-pulse">در حال خشاب‌گذاری...</div>}
      </div>

      {/* joystick */}
      {joyUi && (
        <div className="pointer-events-none absolute" style={{ left: joyUi.ox - 60, top: joyUi.oy - 60 }}>
          <div className="w-[120px] h-[120px] rounded-full border-2 border-white/40 bg-white/10" />
          <div className="absolute w-12 h-12 rounded-full bg-white/60" style={{ left: 36 + joyUi.x - joyUi.ox, top: 36 + joyUi.y - joyUi.oy }} />
        </div>
      )}
      {!joyUi && (
        <div className="pointer-events-none absolute bottom-[12vh] left-[8vw] w-[110px] h-[110px] rounded-full border-2 border-white/25 bg-white/5 flex items-center justify-center text-white/40 text-xs">حرکت</div>
      )}

      {/* right controls */}
      <button {...fireR} className="absolute bottom-[10vh] right-[5vw] w-24 h-24 rounded-full bg-red-600/40 border-4 border-white/50 text-white text-3xl active:bg-red-600/70 flex items-center justify-center">🎯</button>
      <button {...tap(() => (eng().input.aim = !eng().input.aim))} className={`absolute bottom-[34vh] right-[16vw] w-14 h-14 rounded-full border-2 border-white/50 text-white text-xs font-bold ${hud?.aiming ? 'bg-yellow-500/70' : 'bg-black/40'}`}>نشانه</button>
      <button {...tap(() => eng().jump())} className="absolute bottom-[4vh] right-[19vw] w-14 h-14 rounded-full bg-black/40 border-2 border-white/50 text-white text-xs font-bold">پرش</button>
      <button {...tap(() => (eng().crouch = !eng().crouch))} className="absolute bottom-[4vh] right-[27vw] w-12 h-12 rounded-full bg-black/40 border-2 border-white/50 text-white text-[10px] font-bold">خیز</button>
      <button {...tap(() => eng().reload())} className="absolute bottom-[22vh] right-[20vw] w-12 h-12 rounded-full bg-black/40 border-2 border-white/50 text-white text-[10px] font-bold">خشاب</button>
      <button {...tap(() => eng().throwGrenade())} className="absolute bottom-[48vh] right-[5vw] w-12 h-12 rounded-full bg-black/40 border-2 border-white/50 text-white text-sm">💣<span className="absolute -top-1 -left-1 bg-yellow-400 text-black text-[10px] rounded-full w-4 h-4 leading-4">{fa(hud?.grenades ?? 0)}</span></button>
      <button {...tap(() => eng().nextWeapon())} className="absolute bottom-[2vh] right-[36vw] h-10 px-3 rounded-lg bg-black/50 border-2 border-yellow-400/70 text-yellow-300 text-xs font-bold">تعویض سلاح 🔄</button>
      {settings.leftFire && (
        <button {...fireL} className="absolute top-[30vh] left-[18vw] w-16 h-16 rounded-full bg-red-600/30 border-2 border-white/40 text-white text-xl">🎯</button>
      )}
      <button {...tap(() => setPaused(true))} className="absolute top-2 left-[calc(min(24vh,150px)+16px)] w-10 h-10 rounded-lg bg-black/50 border border-white/30 text-white">⏸</button>

      {/* pause menu */}
      {paused && !over && (
        <div className="absolute inset-0 bg-black/70 flex items-center justify-center z-20">
          <div className="bg-zinc-900/95 border border-yellow-500/50 rounded-2xl p-6 w-80 text-center text-white">
            <h2 className="text-2xl font-black text-yellow-400 mb-4">توقف بازی</h2>
            <button onClick={() => setPaused(false)} className="w-full py-3 mb-2 rounded-lg bg-yellow-500 text-black font-black">ادامه</button>
            <button onClick={() => onExit({ kills: hud?.kills ?? 0, score: hud?.score ?? 0 })} className="w-full py-3 rounded-lg bg-zinc-700 font-bold">خروج به منو</button>
            <p className="text-[11px] text-white/50 mt-4">سازنده: محمد حسین محسن آبادی</p>
          </div>
        </div>
      )}

      {/* game over */}
      {over && (
        <div className="absolute inset-0 bg-black/75 flex items-center justify-center z-20">
          <div className="text-center text-white">
            <h2 className={`text-5xl font-black mb-2 ${over.win ? 'text-yellow-400' : 'text-red-500'}`}>{over.win ? 'پیروزی! 🏆' : 'شهید شدی'}</h2>
            <p className="text-white/70 mb-6">{over.win ? 'رزمنده، ماموریت با موفقیت انجام شد' : 'دوباره تلاش کن رزمنده'}</p>
            <div className="flex gap-6 justify-center mb-6 text-lg">
              <div>کشته‌ها<br /><b className="text-3xl text-green-400">{fa(over.kills)}</b></div>
              <div>امتیاز<br /><b className="text-3xl text-yellow-400">{fa(over.score)}</b></div>
              <div>زمان<br /><b className="text-3xl">{fmtTime(over.time)}</b></div>
            </div>
            <button onClick={() => onExit({ kills: over.kills, score: over.score })} className="px-10 py-3 rounded-lg bg-yellow-500 text-black font-black text-xl">بازگشت به منو</button>
          </div>
        </div>
      )}
    </div>
  );
}
